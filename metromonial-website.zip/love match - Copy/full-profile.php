<?php
session_start();
include("database.php");
/*$mysql_hostname = "localhost";
$mysql_user = "root";
$mysql_password = "";
$mysql_database = "love_match";
$prefix = "";
$bd = mysql_connect($mysql_hostname, $mysql_user, $mysql_password) or die("Could not connect database");
mysql_select_db($mysql_database, $bd) or die("Could not select database");*/
?>
<script language="javascript" type="text/javascript">
function f2()
{
window.close();
}
function f3()
{
window.print(); 
}
</script>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>CANDIDATE INFORMATION</title>
<!link href="style.css" rel="stylesheet" type="text/css" />
<!link href="css/hostel.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
     <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<table width="100%" border="0">
<?php 

if (isset($_SESSION['email'])) 
{

  echo $_SESSION['email'];
 //echo $_SESSION['password'];
  $email=$_SESSION['email'];







		 $q1='SELECT * FROM user_registration WHERE email="'.$email.'" limit 1';
    
      $r1=mysqli_query($conn,$q1);
      $count=mysqli_num_rows($r1);
  if ($count>0)
   {
			while($row=mysqli_fetch_array($r1))
			{

			?>
			<tr>
			  <td colspan="2" align="center" class="font1">&nbsp;</td>
  </tr>
			<tr>
			  <td colspan="2" align="center" class="font1">&nbsp;</td>
  </tr>
			
  <tr>
<td width="12%" valign="top" class="heading">Registration Number: </td>
<td class="comb-value1 text-info"><?php echo $row['id'];?></td>
</tr>

			<tr>
			  <td colspan="2"  class="font text-danger"><?php echo ucfirst($row['name']);?>  <span class="font1"> information &raquo;</span> </td>

<td> <img src="<?php echo $row["photo"];?>" height="150" width="150" style="border-radius: 100px">

</td>

  </tr>
			<tr>
			  <td colspan="2"  class="font">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		      <div align="right">Reg Date : <span class="comb-value"><?php echo $row['date'];?></span></div></td>
  </tr>
			
			<tr>
			  <td colspan="2"  class="font1"><table width="100%" border="0">
                <tr>
                  <td width="32%" valign="top" class="heading">Merital Status : </td>
                  
                      <td class="comb-value1"><span class="comb-value"><?php echo $row['merital'];?></span></td>
                    </tr>
                  <tr>
                  <td width="22%" valign="top" class="heading">Tribe : </td>
                  
                      <td class="comb-value1"><span class="comb-value"><?php echo $row['tribe'];?></span></td>
                    </tr>
                  
                    <tr>
                    <td width="12%" valign="top" class="heading">Date Of Birth : </td>
                      <td class="comb-value1"><?php echo $fpm=$row['dob'];?></td>
                    </tr>
                     
                    <tr>
                    <td width="12%" valign="top" class="heading">Gender : </td>
                      <td class="comb-value1"><?php echo $row['gender'];?></td>
                    </tr>
                    <tr>
                    <td width="12%" valign="top" class="heading">Father_name : </td>
                      <td class="comb-value1"><?php echo $dr=$row['father_name'];?></td>
                    </tr>
                    
  
<tr>
<td width="12%" valign="top" class="heading">Mother Name : </td>
<td class="comb-value1"><?php echo $row['mother_name'];?></td>
</tr>



<tr>
<td width="12%" valign="top" class="heading">Job Profile: </td>
<td class="comb-value1"><?php echo $row['job_profile'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Description : </td>
<td class="comb-value1"><?php echo $row['description'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">salary : </td>
<td class="comb-value1"><?php echo $row['salary'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Job Location: </td>
<td class="comb-value1"><?php echo $row['job_location'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Height : </td>
<td class="comb-value1"><?php echo $row['height'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Contact Number : </td>
<td class="comb-value1"><?php echo $row['phone'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Age : </td>
<td class="comb-value1"><?php echo $row['age'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Email : </td>
<td class="comb-value1"><?php echo $row['email'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Address : </td>
<td class="comb-value1"><?php echo $row['address'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Face Colour: </td>
<td class="comb-value1"><?php echo $row['color'];?></td>
</tr>

<?php } } }?>


                   
                  </table></td>
                </tr>
               
					
                  </table></td>
                </tr>
              </table></td>
  </tr>
		
           
 
	 
    </table></td>
  </tr>

  
  <tr>
    <td colspan="2" align="right" ><form id="form1" name="form1" method="post" action="">
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="14%">&nbsp;</td>
          <td width="35%" class="comb-value"><label>
            <input name="Submit" type="submit"  class="btn btn-primary" value="Prints this Document " onClick="return f3();" />
          </label></td>
          <td width="3%">&nbsp;</td>
          <td width="26%"><label>
            <input name="Submit2" type="submit" class="btn btn-danger" value="Close this document " onClick="return f2();"  />
            
            <td><a href="user_dashboard.php" class="btn btn-outline-info">Back to home page</a></td>
            <tr><td><a href="logout.php" class="btn btn-outline-danger">Logout</a></td></tr>
            <div style="margin: 24px 0;">
   
    



    
  
  </div>
            
          </label></td>
          <td width="8%">&nbsp;</td>
          <td width="14%">&nbsp;</td>
        </tr>
      </table>
        </form>    </td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
</table>
</body>
</html>
