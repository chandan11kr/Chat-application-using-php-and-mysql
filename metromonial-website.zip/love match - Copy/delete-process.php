<?php
session_start();
include'database.php';
$sql = "DELETE FROM user_registration WHERE id='" . $_GET["id"] . "'";
if (mysqli_query($conn, $sql))
 {
    echo "<script type='text/javascript'>alert('Record deleted successfully')</script>";
    header("admin_dashboard.php");
} else 
{
    echo "Error deleting record: " . mysqli_error($conn);
}
mysqli_close($conn);
?>