<?php


if(isset($_POST['login']))
{
  session_start();
include 'database.php';
  $email=$_POST['email'];
  $password=$_POST['password'];
  $name;
  $q='SELECT * FROM `register` WHERE `email`="'.$email.'" and `password`="'.$password.'"';
  $r=mysqli_query($conn,$q);
  //if(mysqli_num_rows>0)
  //{
    $_SESSION['email']=$email;
    header("location:user_dashboard.php");
    echo 'you are now logged in';
 /* }
  else
  {
    
    
    echo "<h3 style='color:red'>sorry!!! Your Email and password deosn't match please try again</h3>";
  }*/
}
?>




<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="index.css">
  <link rel="stylesheet" type="text/css" href="login.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
     <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</head>

<style type="text/css">
  body
  {
    background-image: url(image/bg.jpg);
  }
</style>

<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">Menu</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
	<form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-info my-2 my-sm-0" type="submit">Search</button>
    </form>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item ">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">About</a>
      </li>
      
      <li class="nav-item active">
        <a class="nav-link" href="login.php">Login</a>
      </li>
			<li class="nav-item">
        <a class="nav-link" href="registration.html">registration</a>
      </li>
			<li class="nav-item">
        <a class="nav-link" href="#">Membership Plan</a>
      </li>
			
			<li class="nav-item">
        <a class="nav-link" href="#">Help</a>
      </li>
			<li class="nav-item">
        <a class="nav-link" href="contact.php">Contact</a>
      </li>
			
			</ul>
			





			<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Admin
</button>


<!-- Modal -->
 <p class="statusMsg"></p>
  <form role="form" autocomplete="off" autofill="off" method="post" >
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Admin Login</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
			<div class="input-group mb-3">
  <div class="input-group-prepend">
  	<form method="post" action="admin_registration.php">
    <span class="input-group-text" id="basic-addon1">Authenticate Number</span>
  </div>
  
  <input type="text" class="form-control" placeholder="Authenticate Number" aria-label="Authenticate Number" aria-describedby="basic-addon1" name="Authenticate" id="Authenticate" required>
</div>

<div class="input-group mb-3">
  <input type="text" class="form-control" placeholder="Enter Email" aria-label="Enter Email" aria-describedby="basic-addon2" name="email" id="email">
  <div class="input-group-append">
    <span class="input-group-text" id="basic-addon2">@example.com</span>
  </div>
</div>

<label for="basic-url">Your Password</label>
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" id="basic-addon3">Password</span>
  </div>
  <input type="password" name="password" class="form-control" id="password" aria-describedby="basic-addon3">
</div>


      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" name="login" id="login">Login</button>
      </div>
    </div>
  </div>
</div>
</form>



    </ul>
    
  </div>
</nav>
<center>




<form method="post">
<div class="bg-warning col-7" style="margin-top: 10%">
  <img src="image/images.png" style="width: 150px; height: 150px; border-radius:100px;background-color: white;box-shadow: none;">
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control col-3" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" name="email">
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control col-3" id="exampleInputPassword1" placeholder="Password" name="password">
  </div>
  <div class="form-group form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Check me out</label>
  </div>
  <input type="submit" class="btn btn-primary" name="login">






  </div>
</form>
</center>




</body>
</html>





