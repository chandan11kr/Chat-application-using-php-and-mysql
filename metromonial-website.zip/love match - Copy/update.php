<?php
include 'database.php';
session_start();

if (isset($_POST['update']))
  			 {
  				$name=$_POST['name'];
  				$photo=$_FILES['photo'];


  				//print_r($name);
  				//echo "<br>";
  				
  				$filename=$photo['name'];
  				//print_r($filename);
         // echo "<br>";
  				$fileerror=$photo['error'];
        // print_r($fileerror);
  				$filetmp=$photo['tmp_name'];
  				$fileext=explode('.', $filename);
  				$filecheck=strtolower(end($fileext));

  				$fileextstored=array('png','jpg','jpeg');
  				if (in_array($filecheck, $fileextstored))
  				 {
  					$destinationfile='upload/'.$filename;
  					move_uploaded_file($filetmp, $destinationfile);




$merital=$_POST['merital'];
$tribe=$_POST['tribe'];
//$name=$_POST['name'];
$dob=$_POST['dob'];
$gender=$_POST['gender'];
$father_name=$_POST['father_name'];
$mother_name=$_POST['mother_name'];
$job_profile=$_POST['job_profile'];
$description=$_POST['description'];
$salary=$_POST['salary'];
$job_location=$_POST['job_location'];
$height=$_POST['height'];
$phone=$_POST['phone'];
$age=$_POST['age'];
$email=$_POST['email'];
$password=$_POST['password'];
$address=$_POST['address'];
$color=$_POST['color'];
$date = date('Y-m-d H:i:s');





?>



<script language="javascript" type="text/javascript">
/*function f2()
{
window.close();
}
function f3()
{
window.print(); 
}*/
</script>








<?php

//$q="INSERT INTO user_registration values('','$merital', '$tribe','$name','$dob','$gender', '$father_name','$mother_name', '$job_profile','$description','$salary','$job_location','$height', '$phone','$age','$email','$password','$address','$color','$destinationfile','$date')";
$q="UPDATE user_registration SET tribe='$tribe',name='$name',dob='$dob',gender='$gender',father_name='$father_name',mother_name='$mother_name',job_profile='$job_profile',description='$description',salary='$salary' where email=$email" ;



$result=$conn->query($q);
if ($result)
 {
	
			echo "<script type='text/javascript'>alert ('Your  profile updated')</script>";
 }
else
 {
 		echo "<script type='text/javascript'>alert ('Updation failed')</script>";
 }
}
}

?>







<!DOCTYPE html>
<html>
<head>
	<title>Update Profile</title>
	<link rel="stylesheet" type="text/css" href="index.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
     <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
	<?php 
		//session_start();
		include 'database.php';
		if ($_SESSION['email'])
		 {
			echo $_SESSION['email'];
			$email=$_SESSION['email'];

			$q1='SELECT * FROM user_registration WHERE email="'.$email.'" limit 1';
    
      $r1=mysqli_query($conn,$q1);
      $count=mysqli_num_rows($r1);
  if ($count>0)
   {
			while($row=mysqli_fetch_array($r1))
			{

			?>
			<div class="form-group container bg-white" style="border-radius: 5px">
<h1 class="text-danger bg-secondary"><u><center>UPDATE YOUR PROFILE</center></u></h1>
			<form autocomplete="off"  method="POST" id="form1" name="form1" onsubmit="return confirm('Do you really want to submit the form')" enctype="multipart/form-data" class="needs-validation" novalidate>
          

	


<div class="form-row">
    


<div class="col-md-4 mb-5">
      <label for="validationCustom02">Enter Tribe</label>
      <input type="text" class="form-control" id="tribe" name="tribe" aria-describedby="emailHelp" placeholder="Enter Tribe" value="<?php echo $row['tribe']; ?>" >

      <div class="invalid-feedback">
        Please enter tribe
      </div>
    </div>

    <div class="col-md-4 mb-5">
      <label for="validationCustom02">Name</label>
      <input type="text" class="form-control" id="name" name="name" aria-describedby="emailHelp" placeholder="Enter full name" value="<?php echo $row['name']; ?>" >
      <div class="invalid-feedback">
        Please enter full name
      </div>
    </div>
    <div class="col-md-4 mb-3">
      <label for="validationCustom02">Enter Date Of Birth</label>
      <input type="date" class="form-control" id="validationCustom02"  name="dob"  >
      <div class="invalid-feedback" value="<?php echo date("Y-m-d");?>">
        Please Enter Date Of Birth
      </div>
    </div>



    <div class="col-md-4 mb-3">
      <label for="validationCustom02">Choose Gender</label>
      <select id="inputsemster" class="form-control" name="gender"  >
  <option value="" disabled selected>-Select Gender-</option>
    <option >Male</option>
    <option >Female</option>
    
</select>
      <div class="invalid-feedback">
        Please choose gender
      </div>
    </div>


<div class="col-md-4 mb-5">
      <label for="validationCustom02">Enter Father Name</label>
      <input type="text" class="form-control" id="name" name="father_name" aria-describedby="emailHelp" placeholder="Enter father name" value="<?php echo $row['father_name']; ?>"  >
      <div class="invalid-feedback">
        Please enter father name
      </div>
    </div>


    <div class="col-md-4 mb-5">
      <label for="validationCustom02">Enter Mother Name</label>
      <input type="text" class="form-control" id="name" name="mother_name" aria-describedby="emailHelp" placeholder="Enter mother name" value="<?php echo $row['mother_name']; ?>" >
      <div class="invalid-feedback">
        Please enter mother name
      </div>
    </div>


    <div class="col-md-4 mb-5">
      <label for="validationCustom02">Choose Job Profile</label>
      <select id="inputjob" class="form-control" name="job_profile"  >
  <option value="" disabled selected>-Select Your Job Profile-</option>
    
    <option >Goverment Employee</option>
    <option >Engineer</option>
    <option >Business </option>
    <option >Student</option>
    
    <option >Don't Disclose</option>
    <option >Other</option>
    
</select>

      <div class="invalid-feedback">
        Please choose job profile
      </div>
    </div>


    <div class="col-md-8 mb-3">
      <label for="validationCustom03">Job Description</label>
      <input type="text" class="form-control" id="validationCustom03" placeholder="Add Job Description" value="<?php echo $row['description']; ?>">
      <div class="invalid-feedback">
        Please enter job description
      </div>
    </div>


 <div class="col-md-4 mb-5">
      <label for="validationCustom02">Enter Salary(per month)</label>
      <input type="text" class="form-control" id="salary" name="salary" aria-describedby="emailHelp" placeholder="Enter Salary(per month)" value="<?php echo $row['salary']; ?>"  >
      <div class="invalid-feedback">
        Please enter Salary
      </div>
    </div>


    <div class="col-md-4 mb-5">
      <label for="validationCustom02">Enter Job Location</label>
      <input type="text" class="form-control" id="job_location" name="job_location" aria-describedby="fatherHelp" placeholder="Enter Job Location" value="<?php echo $row['job_location']; ?>" >
      <div class="invalid-feedback">
        Please enter job location
      </div>
    </div>



    <div class="col-md-4 mb-5">
      <label for="validationCustom02">Enter height</label>
      <input type="text" class="form-control" id="height" name="height" aria-describedby="rollHelp" placeholder="Enter height(inch)" value="<?php echo $row['height']; ?>" >
      <div class="invalid-feedback">
        Please enter height
      </div>
    </div>



    <div class="col-md-4 mb-5">
      <label for="validationCustom02">Enter Phone Number</label>
      <input type="text" class="form-control" id="phone" name="phone" aria-describedby="phoneHelp" placeholder="Enter Phone Number" maxlength="10" value="<?php echo $row['phone']; ?>">
      <div class="invalid-feedback">
        Please enter phone
      </div>
    </div>



    <div class="col-md-2 mb-5">
      <label for="validationCustom02">Enter Age</label>
      <input type="text" class="form-control" id="age" name="age" aria-describedby="ageHelp" placeholder="Enter Age" maxlength="2" minlength="2" value="<?php echo $row['age']; ?>" >
      <div class="invalid-feedback">
        Please enter age
      </div>
    </div>


    <div class="col-md-6 mb-5">
      <label for="validationCustom02">Enter Email Id</label>
      <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp" placeholder="Enter Email Id" value="<?php echo $row['email']; ?>" required >
      <div class="invalid-feedback">
        Please enter valid email
      </div>
    </div>


   


    <div class="col-md-4 mb-3">
      <label for="validationCustom04"> Enter Address</label>
       <textarea name="address" class="form-control" id="address" name="address" aria-describedby="addressHelp" placeholder="Enter Your Address"   required ><?php echo $row['address']; ?></textarea>
      <div class="invalid-feedback">
        Please provide a valid Address
      </div>
    </div>
    <div class="col-md-4 mb-3">
      <label for="validationCustom05">Face Colour</label>
      <input type="text" class="form-control" id="color" name="color" aria-describedby="motherHelp" placeholder="Enter Face Colour" value="<?php echo $row['color']; ?>">
      <div class="invalid-feedback">
        Please enter face colour
      </div>
    </div>

<div class="form-row">

    <div class="col-md-4 mb-3">
      <label for="validationCustom05">Upload Image</label>
      <input type="file" accept="image/*" class="form-control-file" id="ImageName" name="photo" value="Upload Photo" onchange="previewFile()"  >
<!div style="width: 150px; height: 150px; border: 2px solid #000000; margin-bottom: 20px;border-radius:100px">

<img src="<?php echo $row['photo'] ?>" style="width: 150px; height: 150px; border-radius:100px;background-color: white;box-shadow: none;margin-left: 300px;margin-top: -50px;border-color: blue;border:2px solid"><br><br>

      <div class="invalid-feedback">
        Please Upload Photo
      </div>
    </div>
</div>

      </div>

      <input class="btn btn-primary" type="submit" name="update" value="Update"  id="register">
          <input type="reset" name="reset" value="Reset" class="btn btn-secondary" ><br>
          Already have an account? <a href="login.php" class="text-danger">Login</a>

    </div>

  </div>




  
</form>

<?php } } 



		}
		else
		{
			header("location:login.php");
		}
	 ?>


<script type="text/javascript">

function previewFile()

{

var preview = document.querySelector('img');

var file = document.querySelector('input[type=file]').files[0];

var reader = new FileReader();

reader.addEventListener("load", function () {

preview.src = reader.result;

}, false);

if (file)

{

reader.readAsDataURL(file);

}

}
</script>
<script>
// Example starter JavaScript for disabling form submissions if there are invalid fields
(function() {
  'use strict';
  window.addEventListener('load', function() {
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.getElementsByClassName('needs-validation');
    // Loop over them and prevent submission
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
  }, false);
})();
</script>
</body>
</html>