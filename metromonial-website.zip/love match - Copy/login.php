<?php
session_start();
?>


<!DOCTYPE html>
<html>
<head>
  <title></title>
  <link rel="stylesheet" type="text/css" href="index.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
     <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

</head>
<body class="bg-secondary">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">Menu</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-info my-2 my-sm-0" type="submit">Search</button>
    </form>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item">
        <a class="nav-link" href="index.html">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">About</a>
      </li>
      
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Login
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="login.php">Metrimony Login</a>
          <a class="dropdown-item" href="member_login.php">Membership Login</a>
          
          <div class="dropdown-divider"></div>
         
        </div>
      </li>






      
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Registration
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="registration.html">Metrimony Registration</a>
          <a class="dropdown-item" href="membership_registration.php">Membership Registration</a>
          
          <div class="dropdown-divider"></div>
         
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="membership_plan.php">Membership Plan</a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="#">Help</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="contact.php">Contact</a>
      </li>
      
      </ul>
      





     



    </ul>
    
  </div>
</nav>



<fieldset style="background-color: #000000;width: 500px;margin: 12px auto;">
    <legend><center><img src="image/images.png" width="100px" height="100px" style="border-radius: 100px"></center></legend>

  <form  method="post">
    <center>
  
     <?php
if(isset($_POST['login']))
{
  
include 'database.php';
  $email=$_POST['email'];
  $password=$_POST['password'];
  $name;
  $q='SELECT * FROM `user_registration` WHERE `email`="'.$email.'" and `password`="'.$password.'"';
  $r=mysqli_query($conn,$q);
  if(mysqli_num_rows($r))
  {
    $_SESSION['email']=$email;
    header("location:user_dashboard.php");
    echo 'you are now logged in';
  }
  else
  {
    
    
    echo "<label style='color:red'>sorry!!! Your Email and password doesn't match please try again</label>";
  }
}
?>
<table>
    <div class="input-group mb-3">
      <span class="input-group-text fa fa-user" id="basic-addon2"></span>
  <input type="text" class="form-control" placeholder="Enter Email" aria-label="Enter Email" aria-describedby="basic-addon2" name="email" id="email" required>
  <div class="input-group-append">
    <span class="input-group-text" id="basic-addon2">@example.com</span>
  </div>
</div>


<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text fa fa-lock" id="basic-addon3"></span>
  </div>
  <input type="password" name="password" class="form-control" id="password" aria-describedby="basic-addon3" placeholder="Enter Password" required="">
</div>
      <tr>
        <td colspan="2">
          <input type="submit" name="login" value="Login" class="btn btn-primary">
          <input type="reset"  value="Clear" class="btn btn-secondary">
          
          <a href="reset_password.php" class="btn btn-info"> Reset Password</a>
        </td>
      </tr>
      <tr>
        <td>
        new user?<a href="registration.html" class="btn btn-outline-warning">register </a>
      </td>
      </tr>
</table>
</fieldset>
</center>
</form>


<?php 
  include("include/footer.php");
 ?>
</body>

</html>