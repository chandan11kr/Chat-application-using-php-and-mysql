<?php
if(isset($_POST['register']))
{

	$con=mysqli_connect("localhost","root","","love_match");

	$name=$_POST['name'];
	$husband=$_POST['husband'];
	$father=$_POST['father'];
	$mother=$_POST['mother'];
	$tribe=$_POST['tribe'];
	$address=$_POST['address'];

	$child1=$_POST['child1'];
	$dob1=$_POST['dob1'];
	$marital_status1=$_POST['marital_status1'];
	$marriage1=$_POST['marriage1'];
    $study1=$_POST['study1'];
	$job1=$_POST['job1'];

	$child2=$_POST['child2'];
	$dob2=$_POST['dob2'];
	$marital_status2=$_POST['marital_status2'];
	$marriage2=$_POST['marriage2'];
    $study2=$_POST['study2'];
	$job2=$_POST['job2'];

	$child3=$_POST['child3'];
	$dob3=$_POST['dob3'];
	$marital_status3=$_POST['marital_status3'];
	$marriage3=$_POST['marriage3'];
    $study3=$_POST['study3'];
	$job3=$_POST['job3'];

	$child4=$_POST['child4'];
	$dob4=$_POST['dob4'];
	$marital_status4=$_POST['marital_status4'];
	$marriage4=$_POST['marriage4'];
    $study4=$_POST['study4'];
	$job4=$_POST['job4'];

 	$child5=$_POST['child5'];
	$dob5=$_POST['dob5'];
	$marital_status5=$_POST['marital_status5'];
	$marriage5=$_POST['marriage5'];
    $study5=$_POST['study5'];
	$job5=$_POST['job5'];

	$permanent_address=$_POST['permanent_address'];
	$present_address=$_POST['present_address'];
	$mobile=$_POST['mobile'];
	$whatsapp=$_POST['whatsapp'];
	$land_line=$_POST['land_line'];
	$aadhaar=$_POST['aadhaar'];
	$email=$_POST['email'];
	$passion=$_POST['passion'];
	$social_activity=$_POST['social_activity'];
	$password=$_POST['password'];

	$sql="INSERT INTO member_registration VALUES('','$name','$husband','$father','$mother','$tribe','$address','$child1','$dob1','$marital_status1','$marriage1','$study1','$job1','$child2','$dob2','$marital_status2','$marriage2','$study2','$job2','$child3','$dob3','$marital_status3','$marriage3','$study3','$job3','$child4','$dob4','$marital_status4','$marriage4','$study4','$job4','$child5','$dob5','$marital_status5','$marriage5','$study5','$job5','$permanent_address','$present_address','$mobile','$whatsapp','$land_line','$aadhaar','$email','$passion','$social_activity','$password')";

	$r1=mysqli_query($con, $sql);
	if ($r1) 
	{
	 	echo "<script type='text/javascript'>alert('Registration successfully')</script>";	
	 	header("location:member_login.php");
	}
	else
	{
	 	echo "<script type='text/javascript'>alert('Registration  not successfully')</script>";		}
}


?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>


</head>
<body class=bg-dark>



<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">Menu</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
	<form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-info my-2 my-sm-0" type="submit">Search</button>
    </form>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.html">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="about.php">About</a>
      </li>
      
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Login
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="login.php">Metrimony Login</a>
          <a class="dropdown-item" href="member_login.php">Membership Login</a>
          
          <div class="dropdown-divider"></div>
         
        </div>
      </li>






      
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Registration
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="registration.html">Metrimony Registration</a>
          <a class="dropdown-item" href="membership_registration.php">Membership Registration</a>
          
          <div class="dropdown-divider"></div>
         
        </div>
      </li>
			<li class="nav-item">
        <a class="nav-link" href="membership_plan.php">Membership Plan</a>
      </li>
			
			<li class="nav-item">
        <a class="nav-link" href="help.php">Help</a>
      </li>
			<li class="nav-item">
        <a class="nav-link" href="contact.php">Contact</a>
      </li>
			
			</ul>
			





			<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Admin
</button>


<!-- Modal -->
 <p class="statusMsg"></p>
  <form role="form" autocomplete="off" autofill="off" method="post" >
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Admin Login</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
			<div class="input-group mb-3">
  <div class="input-group-prepend">
  	<form method="post" action="admin_registration.php">
    <span class="input-group-text" id="basic-addon1">Authenticate Number</span>
  </div>
  
  <input type="text" class="form-control" placeholder="Authenticate Number" aria-label="Authenticate Number" aria-describedby="basic-addon1" name="Authenticate" id="Authenticate" required>
</div>

<div class="input-group mb-3">
  <input type="text" class="form-control" placeholder="Enter Email" aria-label="Enter Email" aria-describedby="basic-addon2" name="email" id="email">
  <div class="input-group-append">
    <span class="input-group-text" id="basic-addon2">@example.com</span>
  </div>
</div>

<label for="basic-url">Your Password</label>
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" id="basic-addon3">Password</span>
  </div>
  <input type="password" name="password" class="form-control" id="password" aria-describedby="basic-addon3">
</div>


      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" name="login" id="login">Login</button>
      </div>
    </div>
  </div>
</div>
</form>



    </ul>
    
  </div>
</nav>


	

		
		


<div class="container bg-white">
  <h1 class="text-success"><U><center>MEMBER REGISTRATION</center></U></h1>

  <form class="needs-validation" method="post" novalidate>
  <div class="form-row">
    <div class="col-md-4 mb-3">
      <label for="validationCustom01">Enter Name</label>
      <input type="text" name="name" class="form-control" id="validationCustom01" placeholder="First name"  required>
      <div class="invalid-feedback">
        Please enter name
      </div>
    </div>
    <div class="col-md-4 mb-3">
      <label for="validationCustom02">Enter Husband/Wife</label>
      <input type="text" class="form-control" id="validationCustom02" placeholder="Enter Husband/Wife" name="husband"  required>
      <div class="invalid-feedback">
        Please Enter Husband/wife Name
      </div>
    </div>
    <div class="col-md-4 mb-3">
      <label for="validationCustomUsername">Father Name</label>
      <div class="input-group">
        
        <input type="text" name="father" class="form-control" id="validationCustomUsername" placeholder="Father Name" aria-describedby="inputGroupPrepend" required>
        <div class="invalid-feedback">
         	Please enter father name
        </div>
      </div>
    </div>
  </div>
  <div class="form-row">
    <div class="col-md-4 mb-3">
      <label for="validationCustom03">Enter Mother name</label>
      <input type="text" name="mother" class="form-control" id="validationCustom03" placeholder="Mother Name" required>
      <div class="invalid-feedback">
        Please enter mother name
      </div>
    </div>
    <div class="col-md-4 mb-3">
      <label for="validationCustom02">Enter Tribe</label>
      <input type="text" name="tribe" class="form-control" id="validationCustom02" placeholder="Enter Tribe"  required>
      <div class="invalid-feedback">
        Please enter tribe
      </div>
    </div>
    <div class="col-md-6 mb-3">
      <label for="validationCustom02">Enter Permanent Address</label>
      <input type="text" name="permanent_address" class="form-control" id="validationCustom02" placeholder="Enter Permanent Address"  required>
      <div class="invalid-feedback">
        Please enter permanent address
      </div>
    </div>
    <div class="col-md-6 mb-3">
      <label for="validationCustom02">Enter Present Address</label>
      <input type="text" name="present_address" class="form-control" id="validationCustom02" placeholder="Enter Present Address"  required>
      <div class="invalid-feedback">
        Please enter present address
      </div>
    </div>
    








<table class="table table-hover table-responsive scroll-auto border-striped" style="border: 2px solid black">
	<thead style="border: 2px solid black" class="bg-dark text-white">
		<tr style="border: 2px solid black">

		<th style="border: 2px solid black">
			name of son/daughter 
		</th>
		<th style="border: 2px solid black">
			Date of Birth
		</th>
		<th style="border: 2px solid black">
			married/unmarried
		</th>
		<th style="border: 2px solid black">
			name of daughter/son in low
		</th>
		<th style="border: 2px solid black">
			place name of leave/study/work whare in present
		</th>
		<th style="border: 2px solid black">
			job/occupation/other
		</th>
		<tr>
	</thead>
	<tbody style="border: 2px solid black">
		<tr style="border: 2px solid black">
			<td style="border: 2px solid black">
				<input type="text" name="child1" class="form-control" placeholder="Enter Son/Daughter Name">
			</td>
			<td style="border: 2px solid black">
				<input type="date" name="dob1" class="form-control">
			</td>
			<td style="border: 2px solid black">
				<select class="form-control" name="marital_status1" required>
					<option selected disabled>-Marital Status-</option>
					<option>Married</option>
					<option>Unmarried</option>
				</select>
			</td>
			<td style="border: 2px solid black">
				<input type="text" name="marriage1" class="form-control" placeholder="name of daughter/son in low">
			</td>
			<td style="border: 2px solid black">
				<input type="text" name="study1" class="form-control" placeholder="place name of live/study/work whare in present">
			</td>
			<td style="border: 2px solid black">
				<input type="text" name="job1" class="form-control" placeholder="job/occupation/other">
			</td>
		</tr>

		<tr style="border: 2px solid black">
			<td style="border: 2px solid black">
				<input type="text" name="child2" class="form-control" placeholder="Enter Son/Daughter Name">
			</td>
			<td style="border: 2px solid black">
				<input type="date" name="dob2" class="form-control" >
			</td>
			<td style="border: 2px solid black">
				<select class="form-control" name="marital_status2" required>
					<option selected disabled>-Marital Status-</option>
					<option>Married</option>
					<option>Unmarried</option>
				</select>
			</td>
			<td style="border: 2px solid black">
				<input type="text" name="marriage2" class="form-control" placeholder="name of daughter/son in low">
			</td>
			<td style="border: 2px solid black">
				<input type="text" name="study2" class="form-control" placeholder="place name of live/study/work whare in present">
			</td>
			<td style="border: 2px solid black">
				<input type="text" name="job2" class="form-control" placeholder="job/occupation/other">
			</td>
		</tr>

		<tr style="border: 2px solid black">
			<td style="border: 2px solid black">
				<input type="text" name="child3" class="form-control" placeholder="Enter Son/Daughter Name">
			</td>
			<td style="border: 2px solid black">
				<input type="Date" name="dob3" class="form-control">
			</td>
			<td style="border: 2px solid black">
				<select class="form-control" name="marital_status3" required>
					<option selected disabled>-Marital Status-</option>
					<option>Married</option>
					<option>Unmarried</option>
				</select>
			</td>
			<td style="border: 2px solid black">
				<input type="text" name="marriage3" class="form-control" placeholder="name of daughter/son in low">
			</td>
			<td style="border: 2px solid black">
				<input type="text" name="study3" class="form-control" placeholder="place name of live/study/work whare in present">
			</td>
			<td style="border: 2px solid black">
				<input type="text" name="job3" class="form-control" placeholder="job/occupation/other">
			</td>
		</tr>

		<tr style="border: 2px solid black">
			<td style="border: 2px solid black">
				<input type="text" name="child4" class="form-control" placeholder="Enter Son/Daughter Name">
			</td>
			<td style="border: 2px solid black">
				<input type="Date" name="dob4" class="form-control">
			</td>
			<td style="border: 2px solid black">
				<select class="form-control" name="marital_status4" required>
					<option selected disabled>-Marital Status-</option>
					<option>Married</option>
					<option>Unmarried</option>
				</select>
			</td>
			<td style="border: 2px solid black">
				<input type="text" name="marriage4" class="form-control" placeholder="name of daughter/son in low">
			</td>
			<td style="border: 2px solid black">
				<input type="text" name="study4" class="form-control" placeholder="place name of live/study/work whare in present">
			</td>
			<td style="border: 2px solid black">
				<input type="text" name="job4" class="form-control" placeholder="job/occupation/other">
			</td>
		</tr>


		<tr style="border: 2px solid black">
			<td style="border: 2px solid black">
				<input type="text" name="child5" class="form-control" placeholder="Enter Son/Daughter Name">
			</td>
			<td style="border: 2px solid black">
				<input type="Date" name="dob5" class="form-control">
			</td>
			<td style="border: 2px solid black">
				<select class="form-control" name="marital_status5" required>
					<option selected disabled>-Marital Status-</option>
					<option>Married</option>
					<option>Unmarried</option>
				</select>
			</td>
			<td style="border: 2px solid black">
				<input type="text" name="marriage5" class="form-control" placeholder="name of daughter/son in low">
			</td>
			<td style="border: 2px solid black">
				<input type="text" name="study5" class="form-control" placeholder="place name of live/study/work whare in present">
			</td>
			<td style="border: 2px solid black">
				<input type="text" name="job5" class="form-control" placeholder="job/occupation/other" >
			</td>
		</tr>
	</tbody>
</table>

     <div class="form-row">
    <div class="col-md-4 mb-3">
      <label for="validationCustom01">Enter Mobile Number</label>
      <input type="text" name="mobile" class="form-control" id="validationCustom01" placeholder="Enter Mobile Number"  required>
      <div class="invalid-feedback">
        Please enter mobile number
      </div>
    </div>
    <div class="col-md-4 mb-3">
      <label for="validationCustom02">Enter WhatsApp Number</label>
      <input type="text" name="whatsapp" class="form-control" id="validationCustom02" placeholder="Enter WhatsApp Number"  required>
      <div class="invalid-feedback">
        Please enter whatsApp number
      </div>
    </div>
    <div class="col-md-4 mb-3">
      <label for="validationCustomUsername">Enter Landline Number</label>
      <div class="input-group">
        
        <input type="text" name="land_line" class="form-control" id="validationCustomUsername" placeholder="Enter Landline Number" aria-describedby="inputGroupPrepend" required>
        <div class="invalid-feedback">
          Please enter landline number 
        </div>
      </div>
</div>






    <div class="col-md-4 mb-3">
      <label for="validationServer01">Enter Aadhaar Number</label>
      <input type="text" name="aadhaar" class="form-control is-valid" id="validationServer01" placeholder="Enter Aadhaar Number" maxlength="12"  required>
      <div class="invalid-feedback">
        Please enter aadhaar number
      </div>
    </div>
    <div class="col-md-4 mb-3">
      <label for="validationServer02">Enter Email ID</label>
      <input type="email" name="email" class="form-control is-valid" id="validationServer02" placeholder="Enter Email ID"  required>
      <div class="invalid-feedback">
        Please enter valid email
      </div>
    </div>
    <div class="col-md-4 mb-3">
      <label for="validationServerUsername">Occupation/Job/Proffession</label>
      <div class="input-group">
        
        <input type="text" name="passion" class="form-control is-invalid" id="validationServerUsername" placeholder="Occupation/Job/Proffession" aria-describedby="inputGroupPrepend3" required>
        <div class="invalid-feedback">
          Please enter occupation
        </div>
      </div>
    </div>
    <div class="col-md-4 mb-3">
      <label for="validationServer01">Enter Social Activity</label>
      <input type="text" name="social_activity" class="form-control is-valid" id="validationServer01" placeholder="Enter Social Activity"  required>
      <div class="invalid-feedback">
        Please enter social activity
      </div>
    </div>
    <div class="col-md-4 mb-3">
      <label for="validationServer02">Enter Password</label>
      <input type="password" name="password" class="form-control is-valid" id="validationServer02" placeholder="Enter Password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}"  required>
      <div class="invalid-feedback">
        
     password must be atleast 1 capital latter, 1 small latter, 1 number, 1 special character and atleast 8 character
      </div>
    </div>

  </div>
</div>
  <div class="form-group">
    <div class="form-check">
      <input class="form-check-input" type="checkbox" value="" id="invalidCheck" required>
      <label class="form-check-label" for="invalidCheck">
        Agree to<a href="term.php">terms and conditions</a> 
      </label>
      <div class="invalid-feedback">
        You must agree before submitting.
      </div>
    </div>
  </div>
  <input class="btn btn-primary" type="submit" value="Register" name="register">
  <input class="btn btn-secondary" type="reset" value="Clear">

</form>
</div>

<script>
// Example starter JavaScript for disabling form submissions if there are invalid fields
(function() {
  'use strict';
  window.addEventListener('load', function() {
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.getElementsByClassName('needs-validation');
    // Loop over them and prevent submission
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
  }, false);
})();
</script>
</form>
</div>

</body>
</html>