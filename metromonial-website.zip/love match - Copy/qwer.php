<?php
session_start();
include 'database.php';
if (isset($_SESSION['email'])) {
	echo $_SESSION['email'];

	$q1= "SELECT * FROM register where email = '".$_SESSION['email']."'";
    
      $r1=mysqli_query($conn,$q1);

			while($row=mysqli_fetch_array($r1))
			{
				echo "hello";
			}

}

?>