
  <!DOCTYPE html>
  <html>
  <head>
  	<title></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
     <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </head>
  <body>
  <div class="container">
  <h1 class="text-center text-white bg-dark"> REGISTRATION DETAILS</h1>	
  <br>
  <div class="table-responsive">
  <table class="table table-border table striped table-hover">
  	<thead>
  		
  		<tbody>
  			<?php
  			/*$con=mysqli_connect('localhost','root');
  			mysqli_select_db($con,'love_match');*/
        include 'database.php';


  			if (isset($_POST['register']))
  			 {
  				$name=$_POST['name'];
  				$photo=$_FILES['photo'];


  				//print_r($name);
  				//echo "<br>";
  				
  				$filename=$photo['name'];
  				//print_r($filename);
         // echo "<br>";
  				$fileerror=$photo['error'];
        // print_r($fileerror);
  				$filetmp=$photo['tmp_name'];
  				$fileext=explode('.', $filename);
  				$filecheck=strtolower(end($fileext));

  				$fileextstored=array('png','jpg','jpeg');
  				if (in_array($filecheck, $fileextstored))
  				 {
  					$destinationfile='upload/'.$filename;
  					move_uploaded_file($filetmp, $destinationfile);




$merital=$_POST['merital'];
$tribe=$_POST['tribe'];
//$name=$_POST['name'];
$dob=$_POST['dob'];
$birth_time=$_POST['birth_time'];
$birth_place=$_POST['birth_place'];
$hobby=$_POST['hobby'];
$reference=$_POST['reference'];
$gender=$_POST['gender'];
$father_name=$_POST['father_name'];
$mother_name=$_POST['mother_name'];
$job_profile=$_POST['job_profile'];
$description=$_POST['description'];
$salary=$_POST['salary'];
$job_location=$_POST['job_location'];
$height=$_POST['height'];
$phone=$_POST['phone'];
$age=$_POST['age'];
$email=$_POST['email'];
$password=$_POST['password'];
$address=$_POST['address'];
$color=$_POST['color'];
$date = date('Y-m-d H:i:s');





?>



<script language="javascript" type="text/javascript">
function f2()
{
window.close();
}
function f3()
{
window.print(); 
}
</script>








<?php

$q="INSERT INTO user_registration values('','$merital', '$tribe','$name','$dob','$birth_time','$birth_place','$hobby','$reference','$gender', '$father_name','$mother_name', '$job_profile','$description','$salary','$job_location','$height', '$phone','$age','$email','$password','$address','$color','$destinationfile','$date')";




$result=$conn->query($q);
if ($result)
 {
	
			echo "<script type='text/javascript'>alert ('You are registered successfully')</script>";


?>


<table>

<tr>
        <td colspan="2" align="center" class="font1">&nbsp;</td>
  </tr>
      <tr>
        <td colspan="2" align="center" class="font1">&nbsp;</td>
  </tr>
      
  
      <tr>
        <td colspan="2"  class="font text-danger"><?php print_r($name);?>  <span class="font1"> information &raquo;</span> </td>



  </tr>
      <tr>
        <td colspan="2"  class="font">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <div align="right">Reg Date : <span class="comb-value"><?php print_r($date);?></span></div></td>
  </tr>
      
      <tr>
        <td colspan="2"  class="font1"><table width="100%" border="0">
                <tr>
                  <td width="32%" valign="top" class="heading">Merital Status : </td>
                  
                      <td class="comb-value1"><span class="comb-value"><?php print_r($merital);?></span></td>
                    </tr>
                  <tr>
                  <td width="22%" valign="top" class="heading">Tribe : </td>
                  
                      <td class="comb-value1"><span class="comb-value"><?php print_r($tribe);?></span></td>
                    </tr>
                  
                    <tr>
                    <td width="12%" valign="top" class="heading">Birth Time : </td>
                      <td class="comb-value1"><?php print_r($birth_time);?></td>
                    </tr>

                    <tr>
                    <td width="12%" valign="top" class="heading">Birth Place : </td>
                      <td class="comb-value1"><?php print_r($birth_place);?></td>
                    </tr>

                    <tr>
                    <td width="12%" valign="top" class="heading">Hobbies : </td>
                      <td class="comb-value1"><?php print_r($hobby);?></td>
                    </tr>

                    <tr>
                    <td width="12%" valign="top" class="heading">Reference : </td>
                      <td class="comb-value1"><?php print_r($reference);?></td>
                    </tr>
                     
                    <tr>
                    <td width="12%" valign="top" class="heading">Gender : </td>
                      <td class="comb-value1"><?php print_r($gender);?></td>
                    </tr>
                    <tr>
                    <td width="12%" valign="top" class="heading">Father_name : </td>
                      <td class="comb-value1"><?php print_r($father_name);?></td>
                    </tr>
                    
  
<tr>
<td width="12%" valign="top" class="heading">Mother Name : </td>
<td class="comb-value1"><?php print_r($mother_name);?></td>
</tr>



<tr>
<td width="12%" valign="top" class="heading">Job Profile: </td>
<td class="comb-value1"><?php print_r($job_profile);?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Description : </td>
<td class="comb-value1"><?php print_r($description);?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">salary : </td>
<td class="comb-value1"><?php print_r($salary);?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Job Location: </td>
<td class="comb-value1"><?php print_r($job_location);?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Height : </td>
<td class="comb-value1"><?php print_r($height);?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Contact Number : </td>
<td class="comb-value1"><?php print_r($phone);?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Age : </td>
<td class="comb-value1"><?php print_r($age);?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Email : </td>
<td class="comb-value1"><?php print_r($email);?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Address : </td>
<td class="comb-value1"><?php print_r($address);?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Face Colour: </td>
<td class="comb-value1"><?php print_r($color);?></td>
</tr>
</table>











     
<?php
			
		}
		else
		{

			
			echo "<script type='text/javascript'>alert ('Email id already registered')</script>";

		//header("location:registration.html");
			
		}
	
}
//}




  			
  		}

  			?>

  		</tbody>
  	</thead>

  	<tr>
    <td colspan="2" align="right" ><form id="form1" name="form1" method="post" action="">
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="14%">&nbsp;</td>
          <td width="35%" class="comb-value"><label>
            <input name="Submit" type="submit"  class="btn btn-primary" value="Print" onClick="return f3();" />
            <td><a href="login.php" class="btn btn-outline-info" >Login</a><br><br>
</td>
<td><a href="#" class="btn btn-outline-info" >Update profile</a><br><br>
</td>
          </label>
          <td width="3%">&nbsp;</td>
          <td width="26%"><label>
            <!input name="Submit2" type="submit" class="btn btn-danger" value="Close this document " onClick="return f2();"  />
            <div style="margin: 24px 0;">
   </td>
    
  </table>
  </div>
</div>

  </body>
  </html>



