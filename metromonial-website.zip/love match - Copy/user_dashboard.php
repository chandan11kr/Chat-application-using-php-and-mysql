<?php
session_start();
include("database.php");
if(isset($_SESSION['email']))
{
  echo $_SESSION['email'];

?>




<!DOCTYPE html>
<html>
<head>
  <title> Love Match</title>
  <!link rel="stylesheet" type="text/css" href="index.css">
  

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>



  ​

<script type="text/javascript">
  $('.carousel').carousel();
</script>


<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">Menu</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-info my-2 my-sm-0" type="submit">Search</button>
    </form>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.html">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">About</a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="login.php">Login</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="registration.html">registration</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="membership_plan.php">Membership Plan</a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="#">Help</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="contact.php">Contact</a>
      </li>
      
      </ul>
      





     



    </ul>
    
  </div>
</nav>


<div class="carousel slide carousel-fade" data-ride="carousel">

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">
        <div class="item active">
        </div>
        <div class="item">
        </div>
        <div class="item">
        </div>
    </div>
</div>

<!-- Remeber to put all the content you want on top of the slider below the slider code -->

<div class="title">
  <h1>CHOOSE YOUR LIFE PARTNER WITH YOUR CHOICE</h1>
</div>
<a href="full-profile.php" class="btn btn-outline-info" >see profile</a>
<a href="update.php" class="btn btn-outline-info" >Update Profile</a>
<a href="logout.php" class="btn btn-outline-info" >Logout</a>
<br><br>
<center>
  <form  method="post">
<div style="border-radius: 4px;border:2px solid" class="bg-secondary">
  
  <div class="btn-group">
  
    <span class="sr-only">Toggle Dropdown</span>
  </button>
  <select class="browser-default custom-select" searchable="Search here.." name="type"required>
    <option value="" disabled selected>Loking for</option>
    <option value="Female">Bride</option>
    <option value="Male">Groom</option>
  </select>

  <select class="browser-default custom-select" searchable="Search here.." name="age_start" required>
    <option value="" disabled selected>-Age-</option>
    <option value="1">18</option>
    <option value="2">19</option>
    <option value="3">20</option>
    <option value="4">21</option>
    <option value="5">22</option>
    <option value="6">23</option>
    <option value="7">24</option>
    <option value="8">25</option>
    <option value="9">26</option>
    <option value="10">27</option>
    <option value="11">19</option>
    <option value="12">28</option>
    <option value="12">29</option>
    <option value="14">30</option>
    <option value="15">31</option>
    <option value="16">32</option>
    <option value="17">33</option>
    <option value="18">34</option>
    <option value="19">35</option>
    <option value="20">36</option>
    <option value="21">37</option>
    <option value="22">38</option>
    <option value="23">39</option>
    <option value="24">40</option>
    <option value="25">41</option>
    <option value="26">42</option>
    <option value="27">43</option>
    <option value="28">44</option>
    <option value="29">45</option>
    <option value="30">46</option>
    <option value="31">47</option>
    <option value="32">48</option>
    <option value="33">49</option>
    <option value="34">50</option>
    <option value="35">51</option>
    <option value="36">52</option>
    <option value="37">53</option>
    <option value="38">54</option>
    <option value="39">55</option>
    <option value="40">56</option>
    <option value="41">57</option>
    <option value="42">58</option>
    <option value="43">59</option>
    <option value="44">60</option>


  </select>To

<select class="browser-default custom-select" searchable="Search here.." name="age_end" required>
    <option value="" disabled selected>Age</option>
    <option value="1">18</option>
    <option value="2">19</option>
    <option value="3">20</option>
    <option value="4">21</option>
    <option value="5">22</option>
    <option value="6">23</option>
    <option value="7">24</option>
    <option value="8" >25</option>
    <option value="9">26</option>
    <option value="10">27</option>
    <option value="11">19</option>
    <option value="12">28</option>
    <option value="12">29</option>
    <option value="14">30</option>
    <option value="15">31</option>
    <option value="16">32</option>
    <option value="17">33</option>
    <option value="18">34</option>
    <option value="19">35</option>
    <option value="20">36</option>
    <option value="21">37</option>
    <option value="22">38</option>
    <option value="23">39</option>
    <option value="24">40</option>
    <option value="25">41</option>
    <option value="26">42</option>
    <option value="27">43</option>
    <option value="28">44</option>
    <option value="29">45</option>
    <option value="30">46</option>
    <option value="31">47</option>
    <option value="32">48</option>
    <option value="33">49</option>
    <option value="34">50</option>
    <option value="35">51</option>
    <option value="36">52</option>
    <option value="37">53</option>
    <option value="38">54</option>
    <option value="39">55</option>
    <option value="40">56</option>
    <option value="41">57</option>
    <option value="42">58</option>
    <option value="43">59</option>
    <option value="44">60</option>

  </select>
<select class="browser-default custom-select" searchable name="job_profile" required>
    <option value="" disabled selected>job_profile</option>
    <option value="Goverment Employee" >Goverment Employee</option>
    <option value="Engineer">Engineer</option>
    <option value="Business">Business </option>
    <option value="Student">Student</option>
 
    <option value="Other">Other</option>
  </select>
  <input class="btn btn-danger" type="submit" name="search" value="Search" onclick="check()" id="register">
</div>
</div>
</form>
</center>        
   
<br>
<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for names.." class="form-control"><br>
<table  class=" table table-hover table-responsive table-striped container" >
<?php 
if (isset($_POST['search'])) 
{
 

require_once("database.php");


echo "<thead><tr style='border: 2px solid red' class='text-info'>
<th style='border :2px solid red'>Religous</th>
<th style='border :2px solid red'>Caste</th>
<th style='border :2px solid red'>Name</th>
<th style='border :2px solid red'>Gender</th><th style='border :2px solid red'>Age</th><th style='border :2px solid red'>Color</th><th style='border :2px solid red'>Photo</th><th style='border :2px solid red'>Send intrest</th></tr></thead>";



$age_start=$_POST['age_start'];
$age_end=$_POST['age_end'];
$job_profile=$_POST['job_profile'];
$type=$_POST['type'];

//$q1='SELECT * FROM `register` WHERE age=   ';




  //$q='SELECT religious,caste,name,gender,age,color,photo FROM user_registration WHERE age BETWEEN "'.$age_start.'" AND "'.$age_end.' ORDER BY age ';

//$q='SELECT * FROM `user_registration` where age BETWEEN $age_start AND $age_end' ;
$q="SELECT * FROM `user_registration` WHERE `age` BETWEEN '$age_start' AND '$age_end' and `job_profile`='$job_profile' and `gender`='$type'  ORDER BY `age` ";
  $r=mysqli_query($conn,$q);
  
//if(mysqli_num_rows($r)>0)
      //    {

  while($row=mysqli_fetch_assoc($r))
  {
  
?>
  <tbody id="myTable">
<tr class='table-primary' style='border: 2px solid'>

  <title><?php echo $_SESSION['email']; ?></title>

<td style="border :2px solid red"><?php echo $row['merital']; ?></td>
<td style="border :2px solid red"><?php echo $row['tribe']; ?></td>
<td style="border :2px solid red"><?php echo $row['name']; ?></td>

<td style="border :2px solid red"><?php echo $row['gender']; ?></td>

<td style="border :2px solid red"><?php echo $row['age']; ?></td>

<td style="border :2px solid red"><?php echo $row['color']; ?></td>


<td style="border :2px solid red"> <img src="<?php echo $row["photo"];?>" height="100" width="100">

</td>
<td style="border :2px solid red;font-size: 36px"><a href="#" class="fa fa-send col-lg" ></a> </td>


</tr>                         
  <tbody id="myTable">
<?php

}
/*}
else
{
echo "<h1 style='color:red'>No record found!!!</h1>"; 
}*/

}
}
else
{
header("location:index.html");
}
 ?>

</table>



<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>


</body>
</html>
