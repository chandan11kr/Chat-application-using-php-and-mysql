<?php
$dbuser="root";
$dbpass="";
$host="localhost";
$db="love_match";
$mysqli =new mysqli($host,$dbuser, $dbpass, $db);
?>