<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>


</head>
<body>
<?php
session_start();

$con=mysqli_connect("localhost","root","","love_match");

if (isset($_SESSION['email']))
 {
	echo $_SESSION['email'];
	$email=$_SESSION['email'];

	$q='SELECT * FROM member_registration WHERE email="'.$email.'"';
	$r=mysqli_query($con,$q);
	$count=mysqli_num_rows($r);
	if ($count>0)
	 {
		while ($row=mysqli_fetch_assoc($r))
		 {
	  ?>
	  <center>
	  <table style="border:2px red">
	  	<tr><th> <U>CANDIDATE INFORMATRION</U></th></tr>
	  	<tr>
	  		<td>
	  			<label class="text-success">ID :</label> 
	  		</td>
	  		<td>
	  			<?php echo $row['id'];?>

	  		</td>


	  		<td>
	  			<label class="text-success">REGISTRATION DATE :</label> 
	  		</td>
	  		<td>
	  			<?php echo $row['date'];?>

	  		</td>
	  	</tr>
	  	<tr>
	  		<td>
	  			<label class="text-success">Name :</label>
	  		</td>
	  		<td>
	  			<?php echo $row['name'];?>

	  		</td>
	  	</tr>

	  	<tr>
	  		<td>
	  			<label class="text-success">Husband/Wife Name :</label>
	  		</td>
	  		<td>
	  			<?php echo $row['husband'];?>

	  		</td>
	  	</tr>

	  	<tr>
	  		<td>
	  			<label class="text-success">FATHER'S NAME :</label>
	  		</td>
	  		<td>
	  			<?php echo $row['father'];?>

	  		</td>
	  	</tr>
	  	<tr>
	  		<td>
	  			<label class="text-success">Mother's Name :</label>
	  		</td>
	  		<td>
	  			<?php echo $row['mother'];?>

	  		</td>
	  	</tr>
	  	<tr>
	  		<td>
	  			<label class="text-success">TRIBE :</label>
	  		</td>
	  		<td>
	  			<?php echo $row['tribe'];?>
	  		</td>
	  	</tr>
	  	<tr>
	  		<td>
	  			<label class="text-success">ADDRESS :</label>
	  		</td>
	  		<td>
	  			<?php echo $row['address'];?>
	  		</td>
	  	</tr>
	  	<tr>
	  		<table>





	  			<tr><th><U>CHILDERN DETAIL</U></th></tr>

	  			<tr class="bg-dark text-white">




<th style="border: 2px solid black">
			name of son/daughter 
		</th>
		<th style="border: 2px solid black">
			Date of Birth
		</th>
		<th style="border: 2px solid black">
			marriage/unmarriage
		</th>
		<th style="border: 2px solid black">
			name of daughter/son in low
		</th>
		<th style="border: 2px solid black">
			place name of leave/study/work whare in present
		</th>
		<th style="border: 2px solid black">
			job/occupation/other
		</th>
	  	</tr>
	  	<tr>
	  		<td style="border: 2px solid black">
	  			<?php echo $row['child1'];?>
	  		</td>
	  		<td style="border: 2px solid black">
	  			<?php echo $row['dob1'];?>
	  		</td style="border: 2px solid black">
	  		<td style="border: 2px solid black">
	  			<?php echo $row['marital_status1'];?>
	  		</td>
	  		<td style="border: 2px solid black">
	  			<?php echo $row['marriage1'];?>
	  		</td>
	  		<td style="border: 2px solid black">
	  			<?php echo $row['study1'];?>
	  		</td>
	  		<td style="border: 2px solid black">
	  			<?php echo $row['job1'];?>
	  		</td>

	  	</tr>		



	  	<tr>
	  		<td style="border: 2px solid black">
	  			<?php echo $row['child2'];?>
	  		</td>
	  		<td style="border: 2px solid black">
	  			<?php echo $row['dob2'];?>
	  		</td style="border: 2px solid black">
	  		<td style="border: 2px solid black">
	  			<?php echo $row['marital_status2'];?>
	  		</td>
	  		<td style="border: 2px solid black">
	  			<?php echo $row['marriage2'];?>
	  		</td>
	  		<td style="border: 2px solid black">
	  			<?php echo $row['study2'];?>
	  		</td>
	  		<td style="border: 2px solid black">
	  			<?php echo $row['job2'];?>
	  		</td>

	  	</tr>


	  	<tr>
	  		<td style="border: 2px solid black">
	  			<?php echo $row['child3'];?>
	  		</td>
	  		<td style="border: 2px solid black">
	  			<?php echo $row['dob3'];?>
	  		</td style="border: 2px solid black">
	  		<td style="border: 2px solid black">
	  			<?php echo $row['marital_status3'];?>
	  		</td>
	  		<td style="border: 2px solid black">
	  			<?php echo $row['marriage3'];?>
	  		</td>
	  		<td style="border: 2px solid black">
	  			<?php echo $row['study3'];?>
	  		</td>
	  		<td style="border: 2px solid black">
	  			<?php echo $row['job3'];?>
	  		</td>

	  	</tr>

	  	<tr>
	  		<td style="border: 2px solid black">
	  			<?php echo $row['child4'];?>
	  		</td>
	  		<td style="border: 2px solid black">
	  			<?php echo $row['dob4'];?>
	  		</td style="border: 2px solid black">
	  		<td style="border: 2px solid black">
	  			<?php echo $row['marital-status4'];?>
	  		</td>
	  		<td style="border: 2px solid black">
	  			<?php echo $row['marriage4'];?>
	  		</td>
	  		<td style="border: 2px solid black">
	  			<?php echo $row['study4'];?>
	  		</td>
	  		<td style="border: 2px solid black">
	  			<?php echo $row['job4'];?>
	  		</td>

	  	</tr>


	  	<tr>
	  		<td style="border: 2px solid black">
	  			<?php echo $row['child5'];?>
	  		</td>
	  		<td style="border: 2px solid black">
	  			<?php echo $row['dob5'];?>
	  		</td style="border: 2px solid black">
	  		<td style="border: 2px solid black">
	  			<?php echo $row['marital_status5'];?>
	  		</td>
	  		<td style="border: 2px solid black">
	  			<?php echo $row['marriage5'];?>
	  		</td>
	  		<td style="border: 2px solid black">
	  			<?php echo $row['study5'];?>
	  		</td>
	  		<td style="border: 2px solid black">
	  			<?php echo $row['job5'];?>
	  		</td>

	  	</tr>													
	  				
	  		
	  	</table>
	  	</tr>


<table>

	  	<tr>
	  		<td>
	  			<label class="text-success">Permanent Address :</label>
	  		</td>
	  		<td>
	  			<?php echo $row['permanent_address'];?>

	  		</td>
	  	</tr>

<tr>
	  		<td>
	  			<label class="text-success">Present Address :</label>
	  		</td>
	  		<td>
	  			<?php echo $row['present_address'];?>

	  		</td>
	  	</tr>

	  	<tr>
	  		<td>
	  			<label class="text-success">mobile Number :</label>
	  		</td>
	  		<td>
	  			<?php echo $row['mobile'];?>

	  		</td>
	  	</tr>


	  	<tr>
	  		<td>
	  			<label class="text-success">WhatsApp Number :</label>
	  		</td>
	  		<td>
	  			<?php echo $row['whatapp'];?>

	  		</td>
	  	</tr>

	  	<tr>
	  		<td>
	  			<label class="text-success">LandLine Number  :</label>
	  		</td>
	  		<td>
	  			<?php echo $row['land_line'];?>

	  		</td>
	  	</tr>

	  	<tr>
	  		<td>
	  			<label class="text-success tab">Aadhaar Number :</label>
	  		</td>
	  		<td>
	  			<?php echo $row['aadhaar'];?>

	  		</td>
	  	</tr>

	  	<tr>
	  		<td>
	  			<label class="text-success">Email ID :</label>
	  		</td>
	  		<td>
	  			<?php echo $row['email'];?>

	  		</td>
	  	</tr>

	  	<tr>
	  		<td>
	  			<label class="text-success">Passion :</label>
	  		</td>
	  		<td>
	  			<?php echo $row['passion'];?>

	  		</td>
	  	</tr>

	  	<tr>
	  		<td>
	  			<label class="text-success">Social Activity :</label>
	  		</td>
	  		<td>
	  			<?php echo $row['social_activity'];?>

	  		</td>
	  	</tr>






	  </table>
	</center><br>
		<?php	  	
	 }
	}
}

?>
<a href="member_logout.php" class="btn btn-outline-danger">Logout</a>
<a href="#" class="btn btn-outline-info">Update Profile</a>
<a href="membership_plan.php" class="btn btn-outline-info">pay</a>
<input type="button" value="Print" onclick="window.print()" class="btn btn-primary">
</body>
</html>