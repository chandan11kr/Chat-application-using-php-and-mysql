<form method="post">
<div class="bg-warning col-7" style="margin-top: 10%">
  <img src="image/images.png" style="width: 150px; height: 150px; border-radius:100px;background-color: white;box-shadow: none;">
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control col-3" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" name="email">
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control col-3" id="exampleInputPassword1" placeholder="Password" name="password">
  </div>
  
  <input type="submit" class="btn btn-primary" name="login" value="Login">






  </div>
</form>




















<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
 



<?php
session_start();
//include("includes/config.php");
/*$mysql_hostname = "localhost";
$mysql_user = "root";
$mysql_password = "";
$mysql_database = "love_match";
$prefix = "";
$bd = mysqli_connect($mysql_hostname, $mysql_user, $mysql_password) or die("Could not connect database");
mysqli_select_db($mysql_database, $bd) or die("Could not select database");*/

include('database.php');
?>
<script language="javascript" type="text/javascript">
function f2()
{
window.close();
}
function f3()
{
window.print(); 
}
</script>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Student  Information</title>
<link href="style.css" rel="stylesheet" type="text/css" />
<link href="hostel.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" border="0">
<?php 
     $q= "SELECT * FROM register where email = '".$_GET['email']."'";


//$q="SELECT * FROM `register` WHERE `age` BETWEEN '$age_start' AND '$age_end' ORDER BY `age` ";


  $r=mysqli_query($conn,$q);
  
if($r->num_rows>0)



      while($row=mysqli_fetch_array($r))
      {
      ?>
      <tr>
        <td colspan="2" align="center" class="font1">&nbsp;</td>
  </tr>
      <tr>
        <td colspan="2" align="center" class="font1">&nbsp;</td>
  </tr>
      
      <tr>
        <td colspan="2"  class="font"><?php echo ucfirst($row['name']);?>  <span class="font1"> information &raquo;</span> </td>
  </tr>

  <tr>
    <td > <img src="<?php echo $row["photo"];?>" height="100" width="100">

</td>
  </tr>

      <tr>
        <td colspan="2"  class="font">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <div align="right">Reg Date : <span class="comb-value"><?php echo $row['date'];?></span></div></td>
  </tr>
      
      <tr>
        <td colspan="2"  class="font1"><table width="100%" border="0">
                <tr>
                  <td width="32%" valign="top" class="heading">Religious : </td>
                  
                      <td class="comb-value1"><span class="comb-value"><?php echo $row['religious'];?></span></td>
                    </tr>
                  <tr>
                  <td width="22%" valign="top" class="heading">Caste : </td>
                  
                      <td class="comb-value1"><span class="comb-value"><?php echo $row['caste'];?></span></td>
                    </tr>
                  
                    <tr>
                    <td width="12%" valign="top" class="heading">Name : </td>
                      <td class="comb-value1"><?php echo $fpm=$row['name'];?></td>
                    </tr>
                     
                    <tr>
                    <td width="12%" valign="top" class="heading">Date Of Birth: </td>
                      <td class="comb-value1"><?php echo $row['dob'];?></td>
                    </tr>
                    <tr>
                    <td width="12%" valign="top" class="heading">Gender: </td>
                      <td class="comb-value1"><?php echo $dr=$row['gender'];?></td>
                    </tr>
                    
  
<tr>
<td width="12%" valign="top" class="heading">Father Name : </td>
<td class="comb-value1"><?php echo $row['father_name'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Reg no: </td>
<td class="comb-value1"><?php echo $row['id'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Mother Name: </td>
<td class="comb-value1"><?php echo $row['mother_name'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Job Profile: </td>
<td class="comb-value1"><?php echo $row['job_profile'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Job Description: </td>
<td class="comb-value1"><?php echo $row['description'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Salary: </td>
<td class="comb-value1"><?php echo $row['salary'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Job Location: </td>
<td class="comb-value1"><?php echo $row['job_location'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Height(inch): </td>
<td class="comb-value1"><?php echo $row['height'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Contact No.: </td>
<td class="comb-value1"><?php echo $row['phone'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Age: </td>
<td class="comb-value1"><?php echo $row['age'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Email: </td>
<td class="comb-value1"><?php echo $row['email'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Address: </td>
<td class="comb-value1"><?php echo $row['address'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Face Colour: </td>
<td class="comb-value1"><?php echo $row['color'];?></td>
</tr>




<?php } ?>


                   
                  </table></td>
                </tr>
               
          
                  </table></td>
                </tr>
              </table></td>
  </tr>
    
           
 
   
    </table></td>
  </tr>

  
  <tr>
    <td colspan="2" align="right" ><form id="form1" name="form1" method="post" action="">
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="14%">&nbsp;</td>
          <td width="35%" class="comb-value"><label>
            <input name="Submit" type="submit" class="txtbox4" value="Prints this Document " onClick="return f3();" />
          </label></td>
          <td width="3%">&nbsp;</td>
          <td width="26%"><label>
            <input name="Submit2" type="submit" class="txtbox4" value="Close this document " onClick="return f2();"  />
          </label></td>
          <td width="8%">&nbsp;</td>
          <td width="14%">&nbsp;</td>
        </tr>
      </table>
        </form>    </td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
</table>
</body>
</html>





</body>
</html>

















<form method="post">
<div class="bg-warning col-7" style="margin-top: 10%">
  <img src="image/images.png" style="width: 150px; height: 150px; border-radius:100px;background-color: white;box-shadow: none;">
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control col-3" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" name="email">
    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control col-3" id="exampleInputPassword1" placeholder="Password" name="password">
  </div>
  <div class="form-group form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Check me out</label>
  </div>
  <button type="submit" class="btn btn-primary" value="Login" name="login">Submit</button>






  </div>
</form>
</center>














<table width="100%" border="0">
<?php 
     $q= "SELECT * FROM register where email = '".$_GET['email']."'";


//$q="SELECT * FROM `register` WHERE `age` BETWEEN '$age_start' AND '$age_end' ORDER BY `age` ";


  $r=mysqli_query($conn,$q);
  
if($r->num_rows>0)



      while($row=mysqli_fetch_array($r))
      {
      ?>
      <tr>
        <td colspan="2" align="center" class="font1">&nbsp;</td>
  </tr>
      <tr>
        <td colspan="2" align="center" class="font1">&nbsp;</td>
  </tr>
      
      <tr>
        <td colspan="2"  class="font"><?php echo ucfirst($row['name']);?>  <span class="font1"> information &raquo;</span> </td>
  </tr>
      <tr>
        <td colspan="2"  class="font">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <div align="right">Reg Date : <span class="comb-value"><?php echo $row['date'];?></span></div></td>
  </tr>
      <tr>
        <td colspan="2"  class="heading" style="color: red;">Room Related Info &raquo; </td>
  </tr>
      <tr>
        <td colspan="2"  class="font1"><table width="100%" border="0">
                <tr>
                  <td width="32%" valign="top" class="heading">Religious : </td>
                  
                      <td class="comb-value1"><span class="comb-value"><?php echo $row['religious'];?></span></td>
                    </tr>
                  <tr>
                  <td width="22%" valign="top" class="heading">Caste : </td>
                  
                      <td class="comb-value1"><span class="comb-value"><?php echo $row['caste'];?></span></td>
                    </tr>
                  
                    <tr>
                    <td width="12%" valign="top" class="heading">Name : </td>
                      <td class="comb-value1"><?php echo $fpm=$row['name'];?></td>
                    </tr>
                     <tr>
                    <td width="12%" valign="top" class="heading">Date Of Birth: </td>
                      <td class="comb-value1"><?php if($row['foodstatus']==0)
{
  echo "Without Food";
}
else
{
  echo "With Food";
}
                      ;?></td>
                    </tr>
                    <tr>
                    <td width="12%" valign="top" class="heading">Date Of Birth: </td>
                      <td class="comb-value1"><?php echo $row['dob'];?></td>
                    </tr>
                    <tr>
                    <td width="12%" valign="top" class="heading">Gender: </td>
                      <td class="comb-value1"><?php echo $dr=$row['gender'];?></td>
                    </tr>
                    <tr>
                    <td width="12%" valign="top" class="heading">Total Fee: </td>
                      <td class="comb-value1">
                      <?php if($row['foodstatus']==1)
                      { 
                        $fd=2000; 
                        echo (($dr*$fpm)+$fd);
                      }
                        else
                        {
                          echo $dr*$fpm;
                        }
                      ?></td>
                    </tr>
  <tr>
   <td colspan="2" align="left"  class="heading" style="color: red;">Personal Info &raquo; </td>
  </tr>
<tr>
<td width="12%" valign="top" class="heading">Father Name : </td>
<td class="comb-value1"><?php echo $row['father_name'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Reg no: </td>
<td class="comb-value1"><?php echo $row['id'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Mother Name: </td>
<td class="comb-value1"><?php echo $row['mother_name'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Job Profile: </td>
<td class="comb-value1"><?php echo $row['Job_profile'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Job Description: </td>
<td class="comb-value1"><?php echo $row['description'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Salary: </td>
<td class="comb-value1"><?php echo $row['salary'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Job Location: </td>
<td class="comb-value1"><?php echo $row['job_location'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Height(inch): </td>
<td class="comb-value1"><?php echo $row['height'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Contact No.: </td>
<td class="comb-value1"><?php echo $row['phone'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Age: </td>
<td class="comb-value1"><?php echo $row['age'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Email: </td>
<td class="comb-value1"><?php echo $row['email'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Address: </td>
<td class="comb-value1"><?php echo $row['guardianContactno'];?></td>
</tr>
<tr>
        <td colspan="2"  class="heading" style="color: red;">Correspondence Address  &raquo; </td>
  </tr>
<tr>
<td width="12%" valign="top" class="heading">Address: </td>
<td class="comb-value1"><?php echo $row['corresAddress'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">City: </td>
<td class="comb-value1"><?php echo $row['corresCIty'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">State: </td>
<td class="comb-value1"><?php echo $row['corresState'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Pincode: </td>
<td class="comb-value1"><?php echo $row['corresPincode'];?></td>
</tr>
<tr>
        <td colspan="2"  class="heading" style="color: red;">Permanent Address  &raquo; </td>
  </tr>
<tr>
<td width="12%" valign="top" class="heading">Address: </td>
<td class="comb-value1"><?php echo $row['pmntAddress'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">City: </td>
<td class="comb-value1"><?php echo $row['pmntCity'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">State: </td>
<td class="comb-value1"><?php echo $row['pmnatetState'];?></td>
</tr>

<tr>
<td width="12%" valign="top" class="heading">Pincode: </td>
<td class="comb-value1"><?php echo $row['pmntPincode'];?></td>
</tr>
<tr>
<td width="12%" valign="top" class="heading">State: </td>
<td class="comb-value1"><?php echo $row['pmnatetState'];?></td>
</tr>
<?php } ?>


                   
                  </table></td>
                </tr>
               
          
                  </table></td>
                </tr>
              </table></td>
  </tr>
    
           
 
   
    </table></td>
  </tr>

  
  <tr>
    <td colspan="2" align="right" ><form id="form1" name="form1" method="post" action="">
      <table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td width="14%">&nbsp;</td>
          <td width="35%" class="comb-value"><label>
            <input name="Submit" type="submit" class="txtbox4" value="Prints this Document " onClick="return f3();" />
          </label></td>
          <td width="3%">&nbsp;</td>
          <td width="26%"><label>
            <input name="Submit2" type="submit" class="txtbox4" value="Close this document " onClick="return f2();"  />
          </label></td>
          <td width="8%">&nbsp;</td>
          <td width="14%">&nbsp;</td>
        </tr>
      </table>
        </form>    </td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
</table>
</body>
</html>
