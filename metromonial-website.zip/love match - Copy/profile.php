<?php
//require_once("user_session.php");

require_once("database.php");
//require_once("functions.php");
session_start();

echo $_SESSION['email'];
$query = " SELECT * FROM `user_registration` WHERE id = '{$_SESSION['email']}' ";
$run_query = mysqli_query($conn, $query);
    
if(mysqli_num_rows($run_query) == 1){
while($result = mysqli_fetch_assoc($run_query)){
 $result['name'];
echo $result['email'];
echo $result['phone'];
echo $result['address'];
}
}
?>


<!DOCTYPE html>
<html>
    <head>
        <title>User Profile</title>
        <meta charset="utf-8" />
        <link rel="stylesheet" type="text/css" href="css/form.css" />   
    </head>
    <body>
        <div id="profile">
            <center><img src="img/avatar.gif" alt /></center>
            
            <p>
                <form method="POST" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
                    <input type="submit" name="logout_btn" value="Logout" />
                </form>
            </p>
        </div>
    </body>
</html>