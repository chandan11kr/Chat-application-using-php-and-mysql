<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="index.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
     <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">



</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">Menu</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
	<form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-info my-2 my-sm-0" type="submit">Search</button>
    </form>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">About</a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="login.php">Login</a>
      </li>
			<li class="nav-item">
        <a class="nav-link" href="registration.html">registration</a>
      </li>
			<li class="nav-item">
        <a class="nav-link" href="#">Membership Plan</a>
      </li>
			
			<li class="nav-item">
        <a class="nav-link" href="#">Help</a>
      </li>
			<li class="nav-item">
        <a class="nav-link" href="contact.php">Contact</a>
      </li>
			
			</ul>
			





			<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Admin
</button>


<!-- Modal -->
 <p class="statusMsg"></p>
  <form role="form" autocomplete="off" autofill="off" method="post" >
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Admin Login</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
			<div class="input-group mb-3">
  <div class="input-group-prepend">
  	<form method="post" action="admin_registration.php">
    <span class="input-group-text" id="basic-addon1">Authenticate Number</span>
  </div>
  
  <input type="text" class="form-control" placeholder="Authenticate Number" aria-label="Authenticate Number" aria-describedby="basic-addon1" name="Authenticate" id="Authenticate" required>
</div>

<div class="input-group mb-3">
  <input type="text" class="form-control" placeholder="Enter Email" aria-label="Enter Email" aria-describedby="basic-addon2" name="email" id="email">
  <div class="input-group-append">
    <span class="input-group-text" id="basic-addon2">@example.com</span>
  </div>
</div>

<label for="basic-url">Your Password</label>
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" id="basic-addon3">Password</span>
  </div>
  <input type="password" name="password" class="form-control" id="password" aria-describedby="basic-addon3" required>
</div>


      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" name="login" id="login" value="Login">
      </div>
    </div>
  </div>
</div>
</form>



    </ul>
    
  </div>
</nav>
<br>
<div class="input-group mb-3">
  <div class="input-group-prepend">
<span class=" input-group-text fa fa-search" id="basic-addon3"></span>
</div>
<input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search data" class="form-control col-5" aria-describedby="basic-addon3">
</div>



<br>
<table style='border: 2px solid' class="table-secondary table table-hover table-responsive table-striped`" >

<?php 

require_once("database.php");


echo "<thead><tr style='border: 2px solid red' class='text-info'><th style='border :2px solid red'>Id</th><th style='border :2px solid red'>Religious</th><th style='border :2px solid red'>Caste</th><th style='border :2px solid red'>Name</th><th style='border :2px solid red'>Date Of Birth</th><th style='border :2px solid red'>Gender</th><th style='border :2px solid red'>Father's Name</th><th style='border :2px solid red'>Mother's Name</th><th style='border :2px solid red'>Job Profile</th><th style='border :2px solid red'>Job Description</th><th style='border :2px solid red'>Salary</th><th>Job Location</th><th style='border :2px solid red'>Height</th><th style='border :2px solid red'>Phone</th><th style='border :2px solid red'>Age</th><th style='border :2px solid red'>Email</th><th style='border :2px solid red'>Password</th><th style='border :2px solid red'>Address</th><th style='border :2px solid red'>Color</th><th style='border :2px solid red'>Registration Date</th><th style='border :2px solid red'>Photo</th></tr></thead>";



$age_start=$_POST['age_start'];
$age_end=$_POST['age_end'];


//$q1='SELECT * FROM `register` WHERE age=   ';




	$q="SELECT * FROM `register` WHERE `age` BETWEEN '$age_start' AND '$age_end' ORDER BY `age` ";


	$r=mysqli_query($conn,$q);
	
if($r->num_rows>0)
     	    {

	while($row=mysqli_fetch_assoc($r))
	{
	
?>
  <tbody id="myTable">
<tr class='table-primary' style='border: 2px solid'>

	
<td style="border :2px solid red"><?php echo $row['id']; ?></td>
<td style="border :2px solid red"><?php echo $row['religious']; ?></td>
<td style="border :2px solid red"><?php echo $row['caste']; ?></td>
<td style="border :2px solid red"><?php echo $row['name']; ?></td>
<td style="border :2px solid red"><?php echo $row['dob']; ?></td>
<td style="border :2px solid red"><?php echo $row['gender']; ?></td>
<td style="border :2px solid red"><?php echo $row['father_name']; ?></td>
<td style="border :2px solid red"><?php echo $row['mother_name']; ?></td>
<td style="border :2px solid red"><?php echo $row['job_profile']; ?></td>
<td style="border :2px solid red"><?php echo $row['description']; ?></td>
<td style="border :2px solid red"><?php echo $row['salary']; ?></td>
<td style="border :2px solid red"><?php echo $row['job_location']; ?></td>
<td style="border :2px solid red"><?php echo $row['height']; ?></td>
<td style="border :2px solid red"><?php echo $row['phone']; ?></td>
<td style="border :2px solid red"><?php echo $row['age']; ?></td>
<td style="border :2px solid red"><?php echo $row['email']; ?></td>
<td style="border :2px solid red"><?php echo $row['password']; ?></td>
<td style="border :2px solid red"><?php echo $row['address']; ?></td>
<td style="border :2px solid red"><?php echo $row['color']; ?></td>
<td style="border :2px solid red"><?php echo $row['date']; ?></td>

<td style="border :2px solid red"> <img src="<?php echo $row["photo"];?>" height="100" width="100">

</td>



</tr>                         
  <tbody id="myTable">
<?php

}
}
else
{
echo "<h1 style='color:red'>No record found!!!</h1>";	
}



 ?>

</table>



<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>



</body>
</html>









