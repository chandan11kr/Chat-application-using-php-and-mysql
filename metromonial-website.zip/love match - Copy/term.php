<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h3>Terms and Conditions Template</h3>
<p>Terms and Conditions (T&C) agreements are oftentimes referred to as Terms of Service or Terms of Use agreements. They act as a legal agreement between a company and its users. Currently there are no laws that require a company to have a Terms and Conditions agreement for a mobile app or website, therefore making them completely optional. However, it's a smart move to have one.</p>

<h5>Why is Having a T&C a Good Idea?</h5>
<p>While a T&C isn't required for your app or website, it is still legally binding and enforceable once agreed to. This makes having a T&C a good idea because is allows you to legally control certain aspects of the use of your website or app.</p>

<p>T&Cs can be used to specify and restrict the things that users are allowed and not allowed to do with your app or website. They can be used to prevent potential abuses of your website or app. Furthermore, they can be used as a form of protection for your company.</p>

<p>These agreements become legally binding the moment a user accepts them. Once your users accept your T&C, they are legally bound to the agreement and can have their use of the website or app terminated for breaking the agreement. They can also face legal consequences as a result of the breach of contract. This puts your company in a better position to control your website or app than you would without a T&C.</p>

<p>A T&C a good idea if you are using your app or website to sell a product. In the agreement you can outline payment methods, shipping processes, return policies, refund policies and various other aspects of how transactions will be handled. Outlining these various things in a T&C is a good idea because it is one of the first things that potential customers see when they try to create an account or make a purchase.</p>

<p>Once a customer is aware of your T&C, they will know exactly what they are able to do and not to do and how your company operates. Furthermore, you will also want to include any warranty information and product liability information in a clause within the T&C for your legal protection.</p>

<h3>Benefits of a T&C</h3>
<p>There are several benefits to having a T&C on your app or website. Some of these benefits include limiting your liability, protecting your intellectual property, reserving the right to terminate accounts and restricting abusive behavior.</p>

<p>These benefits give you more control over the way that users interact with your website or app. Furthermore, having the ability to protect your intellectual property and limit your liability is important for your business from several angles ranging from legal concerns to branding and copyright concerns.</p>

<h3>How to Create Your T&C</h3>
<p>There are several things that should be included in a T&C. Depending on the nature of your business, a T&C may not be needed, but it is still important to consider whether or not one would be useful to you.</p>

<h3>Some important questions to ask when deciding whether or not you need or want a T&C are as follows:</h3>

<li>Are users able to create an account?</li>
<li>Are users able to publish or create content on your website or app?</li>
<li>Are users able to purchase products through your website or app?</li>
<li>Are users able to sell products through your website or app?</li>
<li>Will your website or app contain sensitive information?</li>
<li>Do you want to limit your liability for the use of your website or app?</li>
<li>Are you using your website or app to do business with customers or other businesses?</li>
<li>After considering these questions, you should think about the things that you want to include</li><h3> in your T&C. Some of the key things that should be included in your T&C are the following:</h3>

<p>Notice of Agreement: Make it clear to users that the T&C is an agreement between you and them. This notice should be placed at the beginning of your T&C, as Verizon has done in the screenshot below.</p>

<p>Verizon Wireless Customer Agreement introduction section
Rules and Restrictions: Let your users know what your rules and requirements are for using your app or website.</p>

<h3>Here's an example from Nike's Terms of Use.</h3>

<p>Nike Terms of Use: Ground Rules clause
Termination Clause: Enables you to maintain the right to terminate access to prevent users from abusing your website or app. The following example is a termination clause from PlayStation's Terms of Service.</p>

<p>PlayStation Terms of Service: Termination and Cancellation clause
Governing Law: This section discloses to the user which laws are governing the T&C.</p>

<p>Like the below example from Warframe, this section can cover how disputes are handled but it can also cover things such as what happens in the event of a breach, or what can cause the contract to become void.</p>

<p>WarFrame EULA: Governing Law and Dispute Resolution clause
Contact Information: Include your contact information so that users can contact you or a representative at your company with questions about the T&C. Here's how PlayStation has done this in the example below.</p>

<p>PlayStation Terms of Service: Contact Information clause
Warranty Disclaimer/Limitation of Liability: This section should include a fairly standard disclaimer of warranties and a limitation of your liability. Here's another example from Playstation.</p>

<p>PlayStation Terms of Service: Warranty Disclaimer and Limitation of Liability clause
Payment Information: This section should include information regarding what methods of payment are acceptable, how payments are processed and what your return or refund process looks like, if applicable. You can also include any important information about subscriptions, billing and free trials. Note that this is all dependant upon your business model and what products or services you offer.</p>

<h3>PlayStation Terms of Service: Subscriptions clause</h3>
<p>Reserve Right to Make Changes to Agreement: This section allows you to reserve the right to make changes to your T&C. Let users know how you are going to notify them of changes.</p>

<p>Nike Terms of Use: Changes to Terms clause
Intellectual Property Rights: This will allow you to protect your logos, graphic designs, and any other intellectual property that is associated with your website or app. This section serves to protect you from issues with copyrights, trademarks and proprietary rights.</p>

<h3>Here's an example from WarFrame.</h3>

<p>WarFrame EULA: Copyrights, Trademarks and Proprietary Rights clause
How to Display Your T&C
Once written, the next step in making sure that users are aware of your T&C is deciding how to display it. There are several ways that this can be accomplished.</p>

<p>You can place a link to your T&C in the footer of your website or in a menu within your app so that they are always accessible to users and easily findable.</p>

<p>Here's an example of a link to a Terms agreement that's included in a website footer:</p>

<p>Petit Vour website footer screenshot
Here's how a T&C link can be displayed in a mobile app in an About menu:</p>

<p>Groupon app About menu showing legal agreement links
Along with this, you can display your T&C links in some other places on your website and within your app.</p>

<p>Consider including them during the signup process if users can create an account on your website or app, including them in the checkout process if users are able to purchase products on your website or app and before allowing submissions if users are able to post content to your website or app.</p>

<h3>Here's an example of a T&C link included on a mobile signup page:</h3>

<li>Screenshot of Blacklane's mobile app sign-up screen</li>
<li>How to Get Agreement to Your T&C</li>
<li>In order for your T&C to be enforceable, it must be agreed to by your users.</li>

<li>"I Agree" checkboxes are the best current method for getting agreement.</li>


</body>
</html>