    <?php
    session_start();
    require_once("database.php");

    if ($_SESSION['email']==true) 
    {
      //echo "welcome   ".$_SESSION['email'];

    ?>

    <!DOCTYPE html>
    <html>
    <head>
      <title></title>
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

    </head>
    <body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <a class="navbar-brand" href="#">Menu</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <form class="form-inline my-2 my-lg-0">
          <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
          <button class="btn btn-outline-info my-2 my-sm-0" type="submit">Search</button>
        </form>

      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.html">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="about.php">About</a>
          </li>
          
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Login
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="login.php">Metrimony Login</a>
              <a class="dropdown-item" href="member_login.php">Membership Login</a>
              
              <div class="dropdown-divider"></div>
             
            </div>
          </li>






          
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Registration
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="registration.html">Metrimony Registration</a>
              <a class="dropdown-item" href="membership_registration.php">Membership Registration</a>
              
              <div class="dropdown-divider"></div>
             
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="membership_plan.php">Membership Plan</a>
          </li>
          
          <li class="nav-item">
            <a class="nav-link" href="help.php">Help</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">Contact</a>
          </li>
          
          </ul>
          





          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
      Admin
    </button>


    <!-- Modal -->
     <p class="statusMsg"></p>
      <form role="form" autocomplete="off" autofill="off" method="post" >
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Admin Login</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
          <div class="input-group mb-3">
      <div class="input-group-prepend">
        <form method="post" action="admin_registration.php">
        <span class="input-group-text" id="basic-addon1">Authenticate Number</span>
      </div>
      
      <input type="text" class="form-control" placeholder="Authenticate Number" aria-label="Authenticate Number" aria-describedby="basic-addon1" name="Authenticate" id="Authenticate" required>
    </div>

    <div class="input-group mb-3">
      <input type="text" class="form-control" placeholder="Enter Email" aria-label="Enter Email" aria-describedby="basic-addon2" name="email" id="email">
      <div class="input-group-append">
        <span class="input-group-text" id="basic-addon2">@example.com</span>
      </div>
    </div>

    <label for="basic-url">Your Password</label>
    <div class="input-group mb-3">
      <div class="input-group-prepend">
        <span class="input-group-text" id="basic-addon3">Password</span>
      </div>
      <input type="password" name="password" class="form-control" id="password" aria-describedby="basic-addon3">
    </div>


          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-primary" name="login" id="login">Login</button>
          </div>
        </div>
      </div>
    </div>
    </form>



        </ul>
        
      </div>
    </nav>
    <br>
    <?php
    $sql1="SELECT * FROM `admin` WHERE `email`='".$_SESSION['email']."'";
    $result=mysqli_query($conn,$sql1);
    while ($row=mysqli_fetch_assoc($result))
     {
      //echo $row['name'];
      echo "<div class='form-row'><h4 class='text-success'>welcome   </h4><h4 class='text-info'>&nbsp &nbsp".$row['name']."</h3></div>";
    }
    //echo "<div class='form-row'><h3 class='text-success'>welcome   </h3><h4 class='text-danger'>&nbsp &nbsp".$row['name']."</h3></div>";

    ?>
    <br>
    <form method="post">
    <a href="logout.php" class="btn btn-outline-danger">Logout</a>

    <input type="submit" name="metrimony" class="btn btn-outline-info" value="Metrimony Data">
    <input type="submit" name="member" class="btn btn-outline-info" value="Member Data"><br><br>
    </form>
    <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for names.." class="form-control"><br>
    <table style='border: 2px solid' class="table-secondary table table-hover table-responsive">

    <?php
    if (isset($_POST['metrimony']))
     {
      
      echo "<h3 class='text-info'><center><u>METRIMONIAL DATA</u></center></h3>";

    echo "<thead class='bg-dark text-white'>
    <tr style='border: 2px solid red' class='text-white'>
    <th style='border :2px solid red'>Id</th>
    <th style='border :2px solid red'>Religious</th>
    <th style='border :2px solid red'>Caste</th>
    <th style='border :2px solid red'>Name</th>
    <th style='border :2px solid red'>Date Of Birth</th>
    <th style='border :2px solid red'>Birth Time</th>
    <th style='border :2px solid red'>Birth Place</th>
    <th style='border :2px solid red'>Hobbies</th>
    <th style='border :2px solid red'>Reference</th>
    <th style='border :2px solid red'>Gender</th>
    <th style='border :2px solid red'>Father's Name</th>
    <th style='border :2px solid red'>Mother's Name</th>
    <th style='border :2px solid red'>Job Profile</th>
    <th style='border :2px solid red'>Job Description</th>
    <th style='border :2px solid red'>Salary</th>
    <th style='border :2px solid red'>Job Location</th>
    <th style='border :2px solid red'>Height</th>
    <th style='border :2px solid red'>Phone</th>
    <th style='border :2px solid red'>Age</th>
    <th style='border :2px solid red'>Email</th>
    <th style='border :2px solid red'>Password</th>
    <th style='border :2px solid red'>Address</th>
    <th style='border :2px solid red'>Color</th>
    <th style='border :2px solid red'>Registration Date</th>
    <th style='border :2px solid red'>Photo</th>
    <th style='border :2px solid red'>Status</th>
    </tr>
    </thead>";
    //require_once("database.php");
    //$file=$row['file'];
    //session_start();


    $q1='SELECT * FROM `user_registration` order by `date`' ;
    $r1=mysqli_query($conn,$q1);
     //header("Content-type: image/jpg");
    while($row=mysqli_fetch_assoc($r1))
      {
      
    ?>
    <tbody id="myTable" class="overfolw-auto">
    <tr class='table-primary ' style='border: 2px solid;'>
    <td style="border :2px solid red"><?php echo $row['id']; ?></td>
    <td style="border :2px solid red"><?php echo $row['merital']; ?></td>
    <td style="border :2px solid red"><?php echo $row['tribe']; ?></td>
    <td style="border :2px solid red"><?php echo $row['name']; ?></td>
    <td style="border :2px solid red"><?php echo $row['dob']; ?></td>
    <td style="border :2px solid red"><?php echo $row['birth_time']; ?></td>
    <td style="border :2px solid red"><?php echo $row['birth_place']; ?></td>
    <td style="border :2px solid red"><?php echo $row['hobby']; ?></td>
    <td style="border :2px solid red"><?php echo $row['reference']; ?></td>
    <td style="border :2px solid red"><?php echo $row['gender']; ?></td>
    <td style="border :2px solid red"><?php echo $row['father_name']; ?></td>
    <td style="border :2px solid red"><?php echo $row['mother_name']; ?></td>
    <td style="border :2px solid red"><?php echo $row['job_profile']; ?></td>
    <td style="border :2px solid red"><?php echo $row['description']; ?></td>
    <td style="border :2px solid red"><?php echo $row['salary']; ?></td>
    <td style="border :2px solid red"><?php echo $row['job_location']; ?></td>
    <td style="border :2px solid red"><?php echo $row['height']; ?></td>
    <td style="border :2px solid red"><?php echo $row['phone']; ?></td>
    <td style="border :2px solid red"><?php echo $row['age']; ?></td>
    <td style="border :2px solid red"><?php echo $row['email']; ?></td>
    <td style="border :2px solid red"><?php echo $row['password']; ?></td>
    <td style="border :2px solid red"><?php echo $row['address']; ?></td>
    <td style="border :2px solid red"><?php echo $row['color']; ?></td>
    <td style="border :2px solid red"><?php echo $row['date']; ?></td>

    <td style="border :2px solid red"> <img src="<?php echo $row['photo'];?>" height="100" width="100">

    </td>
    <td style="border :2px solid red"><a href="delete-process.php?id=<?php echo $row["id"]; ?>"class="btn btn-outline-danger">Delete</a>
    </td>
    </tr>                         
    </tbody>
    <?php

    }
    $count=mysqli_num_rows($r1);
    echo "<span class='text-danger'>TOTAL NUMBER OF RECORD : </span><span class='text-success'>".$count.'</span>';
    }













if (isset($_POST['member']))
     {
      

    echo "<thead class='bg-dark text-white'>
    <tr style='border: 2px solid red' class='text-white'>
    <th style='border :2px solid red' >Id</th>
    <th style='border :2px solid red' >Name</th>
    <th style='border :2px solid red' >Enter Husband/Wife</th>
    <th style='border :2px solid red' >Father Name</th>
    <th style='border :2px solid red' >Enter Mother name</th>
    <th style='border :2px solid red' >Enter Tribe</th>
    <th style='border :2px solid red' >Enter Permanent Address</th>
    <th style='border :2px solid red' >Enter Present Address</th>
     <th style='border :2px solid red' >Enter Mobile Number</th>
    <th style='border :2px solid red' >Enter WhatsApp Number</th>
    <th style='border :2px solid red'>Enter Landline Number</th>
    <th style='border :2px solid red' >Enter Aadhaar Number</th>
    <th style='border :2px solid red' >Enter Email ID</th>
    <th style='border :2px solid red' >Occupation/Job/Proffession</th>
    <th style='border :2px solid red' >Enter Social Activity</th>
    <th style='border :2px solid red' >Password</th>
    <th style='border :2px solid red' >Registration Date</th>
    <th style='border :2px solid red'  >Children's Details</th>
    <th style='border :2px solid red'>Action</th>
   
    </tr>





    


    </thead>";
    //require_once("database.php");
    //$file=$row['file'];
    //session_start();
    $page=$_GET["page"];
    if ($page=="" || $page=="1") 
    {
      $page1=0;
    }
    else
    {
      $page1=($page*5)-5;
    }


    $q1="SELECT * FROM `member_registration` order by `date` limit $page1,5" ;
    $r1=mysqli_query($conn,$q1);
     //header("Content-type: image/jpg");
    while($row=mysqli_fetch_assoc($r1))
      {
      
    ?>
    <tbody id="myTable" class="overfolw-auto">
    <tr class='table-primary ' style='border: 2px solid;'>
    <td style="border :2px solid red" ><?php echo $row['id']; ?></td>
    <td style="border :2px solid red" ><?php echo $row['name']; ?></td>
    <td style="border :2px solid red" ><?php echo $row['husband']; ?></td>
    <td style="border :2px solid red" ><?php echo $row['father']; ?></td>
    <td style="border :2px solid red" ><?php echo $row['mother']; ?></td>
    <td style="border :2px solid red" ><?php echo $row['tribe']; ?></td>
    <td style="border :2px solid red" ><?php echo $row['permanent_address']; ?></td>
    <td style="border :2px solid red" ><?php echo $row['present_address']; ?></td>
  
    <td style="border :2px solid red" ><?php echo $row['mobile']; ?></td>
    <td style="border :2px solid red" ><?php echo $row['whatapp']; ?></td>
    <td style="border :2px solid red" ><?php echo $row['land_line']; ?></td>
    <td style="border :2px solid red" ><?php echo $row['aadhaar']; ?></td>
    <td style="border :2px solid red" ><?php echo $row['email']; ?></td>
    <td style="border :2px solid red" ><?php echo $row['passion']; ?></td>




   
    <td style="border :2px solid red"><?php echo $row['social_activity']; ?></td>
   
    <td style="border :2px solid red"><?php echo $row['passward']; ?></td>
     <td style="border :2px solid red"><?php echo $row['date']; ?></td>
    <td style="border :2px solid red"><p>
  <a class="btn btn-primary" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
    View
  </a>
 
</p>
<div class="collapse" id="collapseExample">
  <div class="card card-body">
    <table>
      <tr>
        <th>
          name of son/daughter
        </th>
        <th>
          Date of Birth
        </th>
        <th>
          married/unmarried
        </th>
        <th>
          name of daughter/son in low
        </th>
        <th>
          place name of leave/study/work whare in present
        </th>
        <th>
          job/occupation/other
        </th>
      </tr>
      <tr>
        <td><?php echo $row['child1']; ?></td>
        <td><?php echo $row['dob1']; ?></td>
        <td><?php echo $row['marital_status1']; ?></td>
        <td><?php echo $row['marriage1']; ?></td>
        <td><?php echo $row['study1'];?></td>

        <td><?php echo $row['job1']; ?></td>
      </tr>
      <tr>
        <td><?php echo $row['child2']; ?></td>
        <td><?php echo $row['dob2']; ?></td>
        <td><?php echo $row['marital_status2']; ?></td>
        <td><?php echo $row['marriage2']; ?></td>
        <td><?php echo $row['study2']; ?></td>

        <td><?php $row['job2']; ?></td>
      </tr>
      <tr>
        <td><?php echo $row['child3']; ?></td>
        <td><?php echo $row['dob3']; ?></td>
        <td><?php echo $row['marital_status3']; ?></td>
        <td><?php echo $row['marriage3']; ?></td>
        <td><?php echo $row['study3']; ?></td>

        <td><?php echo $row['job3']; ?></td>
      </tr>
      <tr>
        <td><?php echo $row['child4']; ?></td>
        <td><?php echo $row['dob4']; ?></td>
        <td><?php echo $row['marital-status4']; ?></td>
        <td><?php echo $row['marriage4']; ?></td>
        <td><?php echo $row['study4']; ?></td>

        <td><?php echo $row['job4']; ?></td>
      </tr>
      <tr>
        <td><?php echo $row['child5']; ?></td>
        <td><?php echo $row['dob5']; ?></td>
        <td><?php echo $row['marital_status5']; ?></td>
        <td><?php echo $row['marriage5']; ?></td>
        <td><?php echo $row['study5']; ?></td>

        <td><?php echo $row['job5']; ?></td>
      </tr>

    </table>
   
  </div>
</div></td>

   

    </td>
    <td style="border :2px solid red"><a href="member_delete.php?id=<?php echo $row["id"]; ?>"class="btn btn-outline-danger">Delete</a>
    </td>
    </tr>                         
    </tbody>
    <?php

    }
    
    }


    }
    else
    {
    header("location:index.html");
    }
    ?>
    </table>

    <script>
    $(document).ready(function(){
      $("#myInput").on("keyup", function() {
        var value = $(this).val().toLowerCase();
        $("#myTable tr").filter(function() {
          $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
      });
    });
    </script>
      <?php
$q2='SELECT * FROM `member_registration` order by `date`' ;
    $r2=mysqli_query($conn,$q2);
     $count=mysqli_num_rows($r2);
    echo "<span class='text-danger'>TOTAL NUMBER OF RECORD : </span><span class='text-success'>".$count.'</span>';
    $a=$count/5;
    echo "<br>";
    $a= ceil($a);
    for ($b=1; $b<=$a; $b++) 
    { 
      ?>
  
        
    
      <a href="admin_dashboard.php?page=<?php echo $b; ?>" style="text-decoration: none" class="btn btn-primary" ><?php echo $b." "; ?></a>
       
    

      <?php
    }
      ?>

    </body>
    </html>