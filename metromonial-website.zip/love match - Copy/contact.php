<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 300px;
  margin: auto;
  text-align: center;
  font-family: arial;
}

.title {
  color: grey;
  font-size: 18px;
}

button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
  font-size: 18px;
}

a {
  text-decoration: none;
  font-size: 22px;
  color: black;
}

button:hover, a:hover {
  opacity: 0.7;
}
</style>
</head>
<body>

<h2 style="text-align:center">CONTACT</h2>

<div class="card">
  <img src="image/IMG_20181213_135443.jpg" alt="CHANDAN" style="width:100%">
  <h1>CHANDAN KUMAR PASWAN</h1>
  <p class="title">CEO & Founder</p>
  <p>VINOBA BHAVE UNIVERSITY HAZARIBAGH</p>
  <div style="margin: 24px 0;">
   
    <a href="https://twitter.com/chandan11kr" target="_blank" ><i class="fa fa-twitter"></i></a>  
    <a href="https://www.linkedin.com/in/chandan-kumar-592046135/"  target="_blank"><i class="fa fa-linkedin"></i></a>  
    <a href="https://www.facebook.com/profile.php?id=100005532617606" target="_blank"><i class="fa fa-facebook"></i></a> 
    <a href="https://api.whatsapp.com/send?phone=9110022908" target="_blank"><i class="fa fa-whatsapp" ></i></a> 
  
  </div>
  
</div>


<script>
  document.getElementById("id1").style.visibility = "hidden";
var ua = navigator.userAgent.toLowerCase();
var isAndroid = ua.indexOf("android") > -1; //&& ua.indexOf("mobile");
if(isAndroid) {

document.getElementById("id1").style.visibility = "visible";
</script>
<style>
  body {
  height: 3000px; /* Used to enable scrolling */
  background: linear-gradient(50deg, #0fb8ad 10%, #1fc8db 51%, #2cb5e8 85%);
}
</style>
</body>
</html>
