<?php
session_start();
session_destroy();
//unset($_SESSION['email']);
   // header('location:login.php');
header("Location:index.html");

?>