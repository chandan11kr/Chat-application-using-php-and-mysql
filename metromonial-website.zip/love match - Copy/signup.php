<!DOCTYPE html>
<html>
<head>
	<title>Registration</title>
	 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
     <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="#">Menu</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
	<form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-info my-2 my-sm-0" type="submit">Search</button>
    </form>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">About</a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" href="#">Login</a>
      </li>
			<li class="nav-item">
        <a class="nav-link" href="registration.html">registration</a>
      </li>
			<li class="nav-item">
        <a class="nav-link" href="#">Membership Plan</a>
      </li>
			
			<li class="nav-item">
        <a class="nav-link" href="#">Help</a>
      </li>
			<li class="nav-item">
        <a class="nav-link" href="#">Contact</a>
      </li>
			
			</ul>
			





			<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Admin
</button>


<!-- Modal -->
 <p class="statusMsg"></p>
  <form role="form" autocomplete="off" autofill="off" method="post" >
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Admin Login</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
			<div class="input-group mb-3">
  <div class="input-group-prepend">
  	<form method="post" action="admin_registration.php">
    <span class="input-group-text" id="basic-addon1">Authenticate Number</span>
  </div>
  
  <input type="text" class="form-control" placeholder="Authenticate Number" aria-label="Authenticate Number" aria-describedby="basic-addon1" name="Authenticate" id="Authenticate" required>
</div>

<div class="input-group mb-3">
  <input type="text" class="form-control" placeholder="Enter Email" aria-label="Enter Email" aria-describedby="basic-addon2" name="email" id="email">
  <div class="input-group-append">
    <span class="input-group-text" id="basic-addon2">@example.com</span>
  </div>
</div>

<label for="basic-url">Your Password</label>
<div class="input-group mb-3">
  <div class="input-group-prepend">
    <span class="input-group-text" id="basic-addon3">Password</span>
  </div>
  <input type="password" name="password" class="form-control" id="password" aria-describedby="basic-addon3">
</div>


      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary" name="login" id="login">Login</button>
      </div>
    </div>
  </div>
</div>
</form>



    </ul>
    
  </div>
</nav>

<center>


<form autocomplete="off" action="registration.php" method="post" id="form1" name="form1" onsubmit="return confirm('Do you really want to submit the form')" enctype="multipart/form-data">
          

	<div class="form-group bg-info">
       Select Relious:   
<select id="inputsemster" class="form-control col-4" name="religious">
  <option value="" disabled selected>Religion</option>
  	<option >Hindu</option>
  	<option >Muslim</option>
  	<option >Jain</option>
  	<option >Doesn't Matter</option>
</select>

<label for="exampleInputname" >Caste  :</label>
    <input type="text" class="form-control col-4" id="caste" name="caste" aria-describedby="emailHelp" placeholder="Enter caste">

          
    <label for="exampleInputname" >Candidate Name  :</label>
    <input type="text" class="form-control col-4" id="name" name="name" aria-describedby="emailHelp" placeholder="Enter full name">
          
          <label for="exampleInputdob">Date Of Birth  :</label>
          <input type="date" class="form-control col-4" id="dob" name="dob" aria-describedby="dobHelp" >
           <label for="exampleInputgender">Gender  :</label>
          <select id="gender" name="gender" class="form-control col-4">
               <option value="" disabled selected>-Select Your Gender-</option>
               <option  >Male</option>
               <option  >Female</option>
     </select>
     <label for="exampleInputfather" >Father Name  :</label>
    <input type="text" class="form-control col-4" id="father_name" name="father_name" aria-describedby="fatherHelp" placeholder="Enter father name">
          <label for="exampleInputmothername" >Mother Name  :</label>
    <input type="text" class="form-control col-4" id="mother_name" name="mother_name" aria-describedby="motherHelp" placeholder="Enter Mother Name">

    Select Job Profile:   
<select id="inputjob" class="form-control col-4" name="job_profile">
  <option value="" disabled selected>-Select Your Job Profile-</option>
    
    <option >Goverment Employee</option>
    <option >Engineer</option>
    <option >Business </option>
    <option >Student</option>
    <option ></option>
    <option >Don't Disclose</option>
    <option >Other</option>
    
</select>

<label for="exampleInputfather" >Description  :</label>
    <input type="text" class="form-control col-4" id="description" name="description" aria-describedby="fatherHelp" placeholder="add job description">

<label for="exampleInputfather" >Salary  :</label>
    <input type="text" class="form-control col-4" id="salary" name="salary" aria-describedby="fatherHelp" placeholder="Enter salary">

<label for="exampleInputfather" >Job Location  :</label>
    <input type="text" class="form-control col-4" id="job_location" name="job_location" aria-describedby="fatherHelp" placeholder="Enter Job Location">

          <label for="exampleInputname" >Height(inch)</label>
    <input type="text" class="form-control col-4" id="height" name="height" aria-describedby="rollHelp" placeholder="Enter height(inch)">
          <label for="exampleInputphone" >Phone Number  :</label>
    <input type="text" class="form-control col-4" id="phone" name="phone" aria-describedby="phoneHelp" placeholder="Enter Phone Number" maxlength="10">
    <label for="exampleInputphone" >Age  :</label>
    <input type="text" class="form-control col-4" id="age" name="age" aria-describedby="ageHelp" placeholder="Enter Age" maxlength="2" minlength="2">
          <label for="exampleInputname" >Enter Email Id  :</label>
    <input type="email" class="form-control col-4" id="email" name="email" aria-describedby="emailHelp" placeholder="Enter Email Id">
          <label for="exampleInputpassword" >Create Password  :</label>
    <input type="password" class="form-control col-4" id="password" name="password" aria-describedby="passwordHelp" placeholder="Create Password" autocomplete="@off" autofill="@off">
          <label for="exampleInputpassword" >Enter Address  :</label>
          <textarea name="address" class="form-control col-4" id="address" name="address" aria-describedby="addressHelp" placeholder="Enter Your Address" ></textarea>
          <label for="exampleInputcolor" >Color  :</label>
    <input type="text" class="form-control col-4" id="color" name="color" aria-describedby="motherHelp" placeholder="Enter Color"><br>
          <label for="exampleFormControlFile1">Upload photo</label>
    <input type="file" accept="image/*" class="form-control-file col-4" id="ImageName" name="photo" value="Upload Photo" onchange="previewFile()">
<!div style="width: 150px; height: 150px; border: 2px solid #000000; margin-bottom: 20px;border-radius:100px">

<img src="image/images.png" style="width: 150px; height: 150px; border-radius:100px;background-color: white;box-shadow: none;margin-left: 300px;margin-top: -50px"><br><br>


<input class="btn btn-primary" type="submit" name="register" value="Register" onclick="check()" id="register">
          <input type="reset" name="reset" value="Reset" class="btn btn-secondary"><br>
          Already have an account? <a href="login.php" class="text-danger">Login</a>

</div>




<script type="text/javascript">

function previewFile()

{

var preview = document.querySelector('img');

var file = document.querySelector('input[type=file]').files[0];

var reader = new FileReader();

reader.addEventListener("load", function () {

preview.src = reader.result;

}, false);

if (file)

{

reader.readAsDataURL(file);

}

}

<!-- FORM VALIDATION JAVASCRIPT CODE START HERE -->

function FormValidation()

{

rtn = true;

var ImagesName = $("#ImagesName").val();

if (ImagesName == "" || ImagesName == null)

{

$("#ImagesName").css("border", "2px solid red");

//$("#ImagesName").focus();

$("#lblmsg").html("Please Choose Gallery Image");

rtn = false;

}

else

{

$("#ImagesName").css("border", "1px solid #ccc");

$("#lblmsg").html("");

}

return rtn;

}

</script>


    
<script language="javascript">
  function check()
  {
    if(document.form1.name.value=="")
    {
      alert("Please enter name");
      document.form1.name.focus();
      return false;
    }
    
    var valueDate=document.getElementById('dob').value;
    if(!valueDate)
    {
      alert("Please enter date of birth");
      document.form1.dob.focus();
      return false;
    }
    if(document.form1.father_name.value=="")
    {
      alert("Please enter father name");
      document.form1.father_name.focus();
      return false;
    }
    if(document.form1.mother_name.value=="")
    {
      alert("Please enter mother name");
      document.form1.mother_name.focus();
      return false;
    }
    if(document.form1.religious.value=="")
    {
      alert("Please select religious");
      document.form1.religious.focus();
      return false;
    }
    if(document.form1.phone.value=="")
    {
      alert("Please enter phone number");
      document.form1.phone.focus();
      return false;
    }
    if(document.form1.email.value=="")
    {
      alert("Please enter email id");
      document.form1.email.focus();
      return false;
    }
    if(document.form1.password.value=="")
    {
      alert("Please create a password");
      document.form1.password.focus();
      return false;
    }
    if(document.form1.address.value=="")
    {
      alert("Please enter address");
      document.form1.address.focus();
      return false;
    }
  
    return true;

  }

  </script>
          

</form>
</center>




<?php

 if (($_FILES['my_file']['name']!="")){
// Where the file is going to be stored
 $target_dir = "upload/";
 $file = $_FILES['my_file']['name'];
 $path = pathinfo($file);
 $filename = $path['filename'];
 $ext = $path['extension'];
 $temp_name = $_FILES['my_file']['tmp_name'];
 $path_filename_ext = $target_dir.$filename.".".$ext;
 
// Check if file already exists
if (file_exists($path_filename_ext)) {
 echo "Sorry, file already exists.";
 }else{
 move_uploaded_file($temp_name,$path_filename_ext);
 echo "Congratulations! File Uploaded Successfully.";

}
}
?>



<!form name="form" method="post"  enctype="multipart/form-data" >
<!input type="file" name="my_file" /><br /><br />
<!input type="submit" name="submit" value="Upload"/>
<!/form>
  <?php
  /*
  if (($_FILES['my_file']['name']!="")){
// Where the file is going to be stored
 $target_dir = "upload/";
 $file = $_FILES['my_file']['name'];
 $path = pathinfo($file);
 $filename = $path['filename'];
 $ext = $path['extension'];
 $temp_name = $_FILES['my_file']['tmp_name'];
 $path_filename_ext = $target_dir.$filename.".".$ext;
 
// Check if file already exists
if (file_exists($path_filename_ext)) {
 echo "Sorry, file already exists.";
 }else{
 move_uploaded_file($temp_name,$path_filename_ext);
 echo "Congratulations! File Uploaded Successfully.";
 }
}*/
  ?>



</body>
</html>












