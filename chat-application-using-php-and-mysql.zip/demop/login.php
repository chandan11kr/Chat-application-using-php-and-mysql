<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	<form  method="post">
		<center>
	<fieldset style="background-color: #ccffcc;width: 500px;margin: 12px auto;">
		<legend><h1 style="background-color: blue;color:white;width: 500px;margin: 12px auto;border-radius: 10px"><center>USER LOGIN</center></h1></legend>
		<?php
if(isset($_POST['login']))
{
	session_start();
include 'database.php';
	$email=$_POST['email'];
	$password=$_POST['password'];
	$name;
	$q='SELECT * FROM `alexa` WHERE `email`="'.$email.'" and `password`="'.$password.'"';
	$r=mysqli_query($con,$q);
	if(mysqli_num_rows($r))
	{
		$_SESSION['email']=$email;
		header("location:dashboard.php");
		echo 'you are now logged in';
	}
	else
	{
		
		
		echo "<h3 style='color:red'>sorry!!! Your Email and password deosn't match please try again</h3>";
	}
}
?>
<table>
		<tr>
				<td>
					Enter Your Email :
				</td>
				<td>
					<input type="email" name="email" placeholder="Enter Your Email">
				</td>
			</tr>
			<tr>
				<td>
					Enter Your Password :
				</td>
				<td>
					<input type="password" name="password" placeholder="Enter Your Password">
				</td>
			</tr>
			<tr>
				<td colspan="2">
					<input type="submit" name="login" value="Login" style="background-color:#6495ed;color:white;font-size: 16px;border-radius: 4px;border-color: #6495ed"">
					<input type="reset"  value="Clear" style="background-color:#6495ed;color:white;font-size: 16px;border-radius: 4px;border-color: #6495ed">
					<input type="submit" name="login" value="Reset Password" style="background-color:#6495ed;color:white;font-size: 16px;border-radius: 4px;border-color: #6495ed"">
				</td>
			</tr>
			<tr>
				<td>
				new user?<a href="index.html">register </a>
			</td>
			</tr>
</table>
</fieldset>
</center>
</form>

</body>
</html>