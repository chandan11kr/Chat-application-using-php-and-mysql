<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php
session_start();
if(isset($_SESSION['email']))
{
echo '<h3 style="color:#330099">WELCOME '.$_SESSION['email'].'</h3>';





	








}
else
{
	header("location:login.php");
}
?>
<form>
	<div style="overflow: scroll;width: 50%;margin: 20px auto;border: 2px solid red;height: 400px;border-radius: ">
		<div>
			<h1 style="background-color: red;color: white;margin: 0px">
				<center>
					MESSAGE
				</center>
				
			</h1>
		</div>
<?php

	include 'database.php';	
	
$q1="SELECT * FROM alexa where email='".$_SESSION['email']."'";
$r1=mysqli_query($con,$q1);
while($row=mysqli_fetch_assoc($r1))
{
	//$message=$row['message'];
$name=$row['name'];
$mother=$row['mother'];
$father=$row['father'];
	$email=$row['email'];
	/*$id=$row['id'];*/
	
	echo '<h4 style="color:red;margin-left:20px">'.$email.'</h4>';
echo '<h4 style="color:red;margin-left:20px">'.$mother.'</h4>';
echo '<h4 style="color:red;margin-left:20px">'.$father.'</h4>';
	echo '<p style="margin-left:20px">'.$name.'</p>   ';
	
	echo '<hr>';
}	

	if(isset($_POST['send']))
{
	
	$message=$_POST['msg'];
	
	
	$q='INSERT INTO `user_message`VALUES("","'.$message.'","'.$_SESSION['email'].'")';
	$r2=mysqli_query($con,$q);

			echo '<h4 style="color:red; margin-left:20px">'.$_SESSION['email'].'</h4>';
			echo '<p style="margin-left:20px">'.$message.'</p>';


			if($message=="Hi" or $message=="hi" or $message=="Hello" or $message=="hello" )
   {
	   echo '<hr>';
	echo '<h4 style="color:green;text-align:right">Hello '.$_SESSION['email'].' how can i help you?</h4>';
	echo'<hr>';
   }
	elseif($message== "who are you?" or $message=="Who are you?" or $message=="who are you" or $message=="Who are you")
	{
		echo '<hr>';
		echo '<h4 style="color:green;text-align:right">i am machine which is design by chandan</h4>';
		echo '<hr>';
	}
	elseif($message=="How are you?" or	$message=="how are you?" or $message=="How are you" or $message=="how are you" or $message=="HOW ARE YOU" or $message=="HOW ARE YOU?")
	{
		echo '<hr>';
		echo '<h4 style="color:green;text-align:right">i am fine</h4>';
		echo '<hr>';
	}
	else
	{
		echo '<hr>';
		echo '<h4 style="color:green;text-align:right">oh!!! Data not found. Please type correct input</h4>';
		echo '<hr>';
	}
}
if (isset($_POST['delete']))
 {
	$del=$_POST['del'];
	$sql3='Delete  FROM `user_message` WHERE `id`= "'.$del.'"';
	if(mysqli_query($con,$sql3))
	{
		
		echo "<script type='text/javascript'>alert ('message deleted successfully')</script>";
	}
	else 
	{
		echo $sql3;
	}

}
if (isset($_POST['delete_all']))
{
	$sql4='Delete  FROM user_message';
	if(mysqli_query($con,$sql4))
	{
		
		echo "<script type='text/javascript'>alert (' All message deleted successfully')</script>";
	}
	else 
	{
		echo $sql4;
	}
}

if (isset($_POST['logout']))
 {
	header(("Location:logout.php"));
}
?>
	</div>
</form>
<form method="post">
<input type="text" name="msg" placeholder="Type your message here..." style="border-radius: 10px;margin-left: 330px;font-size: 16px">
	

<input type="submit" name="send" value="Send" style="background-color:#6495ed;color:white;font-size: 18px"><br><br>

<label style=";margin-left: 330px">Enter message id :</label><input type="text" name="del">
<input type="submit" name="delete" value="Delete" style="background-color:#6495ed;color:white;font-size: 18px">
<input type="submit" name="delete_all" value="Delete All" style="background-color:#6495ed;color:white;font-size: 18px"><br><br>
<input type="submit" name="logout" value="Logout" style="background-color:#6495ed;color:white;font-size: 18px;width:100%">
</form>
</body>
</html>