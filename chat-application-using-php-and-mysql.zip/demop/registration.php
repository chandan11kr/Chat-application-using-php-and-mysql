<?php
include 'database.php';
$name=$_POST['name'];
$mother=$_POST['mother'];
$father=$_POST['father'];
$email=$_POST['email'];
$pass=$_POST['password'];

$sql="insert into `alexa`  values('".$name."','".$mother."','".$father."','".$email."','".$pass."')";
if(mysqli_query($con,$sql)) 

{
echo "data stored successfully";

}
else
{
	echo "data not stored successfully";
}
?>